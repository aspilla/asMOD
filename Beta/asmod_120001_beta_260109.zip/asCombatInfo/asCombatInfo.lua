﻿local _, ns      = ...;

local configs    = {
	combatalpha = 1,
	normalalpha = 0.5,
}

local _, Class   = UnitClass("player")
ns.classcolor    = RAID_CLASS_COLORS[Class];
ns.hotkeys       = {};

local main_frame = CreateFrame("Frame");
local function update_bars(viewer)
	if not ns.options.ChangeBuffBar then
		return;
	end

	local childs = { viewer:GetChildren() };
	local visiblechilds = {}
	for _, child in ipairs(childs) do
		if child:IsShown() then
			table.insert(visiblechilds, child)
		end
	end

	if #visiblechilds == 0 then
		return
	end

	for _, item in ipairs(visiblechilds) do
		if not item.bconfiged then
			item.bconfiged = true;

			if item.Bar then
				local bar = item.Bar
				bar:SetStatusBarTexture("RaidFrame-Hp-Fill");
				if ns.options.BuffBarClassColor then
					bar:SetStatusBarColor(ns.classcolor.r, ns.classcolor.g, ns.classcolor.b);
				end
				bar.BarBG:Hide();


				bar.bg = bar:CreateTexture(nil, "BACKGROUND");
				bar.bg:SetPoint("TOPLEFT", bar, "TOPLEFT", -1, 1);
				bar.bg:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 1, -1);

				bar.bg:SetTexture("Interface\\Addons\\asCombatInfo\\border.tga");
				bar.bg:SetTexCoord(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
				bar.bg:SetVertexColor(0, 0, 0, 1);
			end

			if item.Icon then
				local button = item.Icon
				local height = item.Bar:GetHeight();

				local rate = 1.2;
				local iconrate = .16;
				button:SetSize(height * rate, height);
				button.Icon:ClearAllPoints();
				button.Icon:SetPoint("CENTER", 0, 0);
				button.Icon:SetSize(height * rate - 2, height - 2);
				button.Icon:SetTexCoord(.08, .92, iconrate, 1 - iconrate);

				if not button.border then
					button.border = button:CreateTexture(nil, "BACKGROUND", "asCombatInfoBorderTemplate");
					button.border:SetAllPoints(button);
					button.border:SetColorTexture(0, 0, 0, 1);
					button.border:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
				else
					button.border:SetAlpha(1)
				end
				button.border:Show()

				if button.Applications then
					local r = button.Applications;
					if r:GetObjectType() == "FontString" then
						r:SetFont(STANDARD_TEXT_FONT, height / 2 + 3, "OUTLINE");
						r:SetTextColor(0, 1, 0);
					end
				end
			end
		end
	end
end

-- Core function to remove padding and apply modifications. Doing Blizzard's work for them.
local function update_buttons(viewer)
	-- Don't apply modifications in edit mode
	if EditModeManagerFrame and EditModeManagerFrame:IsEditModeActive() then
		return
	end
	local isbar = (viewer == BuffBarCooldownViewer);
	if isbar then
		update_bars(viewer);
		return;
	end


	local childs = { viewer:GetChildren() };
	local isbuff = (viewer == BuffIconCooldownViewer);

	-- Get the visible icons (because they're fully dynamic)
	local visiblechilds = {}
	for _, child in ipairs(childs) do
		if child:IsShown() then
			-- Store original position for sorting
			local point, relativeTo, relativePoint, x, y = child:GetPoint(1)
			child.originalX = x or 0
			child.originalY = y or 0
			table.insert(visiblechilds, child)
		end
	end

	if #visiblechilds == 0 then
		return
	end

	for _, button in ipairs(visiblechilds) do
		local rate = 0.9;
		local iconrate = .088;

		if isbuff then
			rate = 0.8;
			iconrate = .16;
		end

		if not button.bconfiged then
			local width = button:GetWidth();
			button.bconfiged = true;
			button:SetSize(width, width * rate);


			if button.Icon then
				local mask = button.Icon:GetMaskTexture(1)
				if mask then
					button.Icon:RemoveMaskTexture(mask);
				end
				button.Icon:ClearAllPoints();
				button.Icon:SetPoint("CENTER", 0, 0);
				button.Icon:SetSize(width - 4, width * rate - 4);
				button.Icon:SetTexCoord(.08, .92, iconrate, 1 - iconrate);
			end


			if button.ChargeCount then
				for _, r in next, { button.ChargeCount:GetRegions() } do
					if r:GetObjectType() == "FontString" then
						r:SetFont(STANDARD_TEXT_FONT, width / 3 + 1, "OUTLINE");
						r:ClearAllPoints();
						r:SetPoint("CENTER", button, "BOTTOM", 0, 1);
						r:SetTextColor(0, 1, 0);
						r:SetDrawLayer("OVERLAY");
						break;
					end
				end
			end

			if button.DebuffBorder then
				button.DebuffBorder:ClearAllPoints();
				button.DebuffBorder:SetPoint("TOPLEFT", button, "TOPLEFT", -4, 4);
				button.DebuffBorder:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 4, -4);
			end

			if button.Applications then
				for _, r in next, { button.Applications:GetRegions() } do
					if r:GetObjectType() == "FontString" then
						r:SetFont(STANDARD_TEXT_FONT, width / 3 + 2, "OUTLINE");
						r:ClearAllPoints();
						r:SetPoint("CENTER", button, "BOTTOM", 0, 1);
						r:SetTextColor(0, 1, 0);
						r:SetDrawLayer("OVERLAY");
						break;
					end
				end
			end


			if not button.border then
				button.border = button:CreateTexture(nil, "BACKGROUND", "asCombatInfoBorderTemplate");
				button.border:SetAllPoints(button);
				button.border:SetColorTexture(0, 0, 0, 1);
				button.border:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
			else
				button.border:SetAlpha(1)
			end
			button.border:Show()

			if button.Cooldown then
				for _, r in next, { button.Cooldown:GetRegions() } do
					if r:GetObjectType() == "FontString" then
						r:SetFont(STANDARD_TEXT_FONT, width / 3 + 1, "OUTLINE");
						r:ClearAllPoints();
						if isbuff then
							r:SetPoint("CENTER", button, "TOP", 0, 0);
						else
							r:SetPoint("CENTER", 0, 0);
						end
						r:SetDrawLayer("OVERLAY");
						break;
					end
				end

				button.asupdate = function()
					if button.cooldownUseAuraDisplayTime == true then
						button.border:SetColorTexture(0, 1, 1);
					else
						button.border:SetColorTexture(0, 0, 0);
					end
				end

				if button.astimer then
					button.astimer:Cancel();
				end

				button.astimer = C_Timer.NewTicker(0.2, button.asupdate);
			end

			if not isbuff then
				if not button.hotkey then
					button.hotkey = button:CreateFontString(nil, "ARTWORK");
					button.hotkey:SetFont(STANDARD_TEXT_FONT, width / 3 - 3, "OUTLINE");
					button.hotkey:SetPoint("TOPRIGHT", button, "TOPRIGHT", -2, -2);
					button.hotkey:SetTextColor(1, 1, 1, 1);
				end
			end
		end

		if not isbuff then
			local spellid = button:GetSpellID();

			if not issecretvalue(spellid) then
				local keytext = ns.hotkeys[button:GetSpellID()];

				if keytext then
					button.hotkey:SetText(keytext);
					button.hotkey:Show();
				else
					button.hotkey:Hide();
				end
			end
		end
	end

	local isHorizontal = viewer.isHorizontal;

	if not isHorizontal then
		return;
	end

	local bcentered = true;

	if isbuff and not ns.options.AlignedBuff then
		bcentered = false;
	end

	local stride = viewer.stride or #visiblechilds
	local overlap = viewer.childXPadding;

	table.sort(visiblechilds, function(a, b)
		if math.abs(a.originalY - b.originalY) < 1 then
			return a.originalX < b.originalX
		end
		return a.originalY > b.originalY
	end)

	-- Reposition buttons respecting orientation and stride
	local buttonWidth = visiblechilds[1]:GetWidth()
	local buttonHeight = visiblechilds[1]:GetHeight()

	-- Calculate grid dimensions
	local numIcons = #visiblechilds

	for i, child in ipairs(visiblechilds) do
		if bcentered then
			local index = i - 1
			local row = math.floor(index / stride)
			local col = index % stride

			-- Determine number of icons in this row
			local rowStart = row * stride + 1
			local rowEnd = math.min(rowStart + stride - 1, numIcons)
			local iconsInRow = rowEnd - rowStart + 1

			-- Compute the actual width of this row
			local rowWidth = iconsInRow * buttonWidth + (iconsInRow - 1) * overlap

			-- Center this row
			local rowStartX = -rowWidth / 2

			-- Column offset inside centered row
			local xOffset = rowStartX + col * (buttonWidth + overlap)
			local yOffset = row * (buttonHeight + overlap)
			child:ClearAllPoints();
			child:SetPoint("TOP", viewer, "TOP", xOffset + buttonWidth / 2, -yOffset);
		else
			local point, relativeTo, relativePoint, x, y = child:GetPoint(1);
			child:ClearAllPoints();
			child:SetPoint(point, relativeTo, relativePoint, x, 0);
		end
	end
end


local updateframe = CreateFrame("Frame");
local todolist = {};
updateframe:Hide()


updateframe:SetScript("OnUpdate", function()
	updateframe:Hide()

	for viewer in pairs(todolist) do
		todolist[viewer] = nil
		update_buttons(viewer)
	end
end)

-- Schedule an update to apply the modifications during the same frame, but after Blizzard is done mucking with things
local function add_todolist(viewer)
	todolist[viewer] = true
	updateframe:Show()
end

local viewers = {
	UtilityCooldownViewer,
	EssentialCooldownViewer,
	BuffIconCooldownViewer,
	BuffBarCooldownViewer
}

local function check_name(name)
	name = string.gsub(name, "Num Pad ", "");
	name = string.gsub(name, "숫자패드 ", "");
	name = string.gsub(name, "Num Pad", "");
	name = string.gsub(name, "숫자패드", "");

	name = string.gsub(name, "Middle Mouse", "M3");
	name = string.gsub(name, "마우스 가운데 버튼", "M3");
	name = string.gsub(name, "Mouse Button (%d)", "M%1");
	name = string.gsub(name, "(%d)번 마우스 버튼", "M%1");
	name = string.gsub(name, "Mouse Wheel Up", "MU");
	name = string.gsub(name, "마우스 휠 위로", "MU");
	name = string.gsub(name, "Mouse Wheel Down", "MD");
	name = string.gsub(name, "마우스 휠 아래로", "MD");
	name = string.gsub(name, "^s%-", "S");
	name = string.gsub(name, "^a%-", "A");
	name = string.gsub(name, "^c%-", "C");
	name = string.gsub(name, "Delete", "Dt");
	name = string.gsub(name, "Page Down", "Pd");
	name = string.gsub(name, "Page Up", "Pu");
	name = string.gsub(name, "Insert", "In");
	name = string.gsub(name, "Del", "Dt");
	name = string.gsub(name, "Home", "Hm");
	name = string.gsub(name, "Capslock", "Ck");
	name = string.gsub(name, "Num Lock", "Nk");
	name = string.gsub(name, "Scroll Lock", "Sk");
	name = string.gsub(name, "Backspace", "Bs");
	name = string.gsub(name, "Spacebar", "Sb");
	name = string.gsub(name, "스페이스 바", "Sb");
	name = string.gsub(name, "End", "Ed");
	name = string.gsub(name, "Up Arrow", "^");
	name = string.gsub(name, "위 화살표", "^");
	name = string.gsub(name, "Down Arrow", "V");
	name = string.gsub(name, "아래 화살표", "V");
	name = string.gsub(name, "Right Arrow", ">");
	name = string.gsub(name, "오른쪽 화살표", ">");
	name = string.gsub(name, "Left Arrow", "<");
	name = string.gsub(name, "왼쪽 화살표", "<");

	return name;
end

local function scan_keys(name, type, hide, total)
	for i = 1, total do
		local f = getglobal(name .. i);
		if not f then
			break
		end
		;
		local hotkey = getglobal(f:GetName() .. "HotKey");
		if not hotkey then
			break
		end
		;

		local text = hotkey:GetText();
		if f.action then
			local actionType, id = GetActionInfo(f.action)

			if (actionType == "spell" or actionType == "macro") and id and text ~= "●" then
				if ns.hotkeys[id] == nil then
					ns.hotkeys[id] = check_name(text);
				end
			end
		end
	end
end

local function check_hotkeys()
	if not ns.options.ShowHotKey then
		return;
	end
	wipe(ns.hotkeys);
	scan_keys("ActionButton", "ACTIONBUTTON", 1, 12);
	scan_keys("MultiBarBottomLeftButton", "MULTIACTIONBAR1BUTTON", 1, 12);
	scan_keys("MultiBarBottomRightButton", "MULTIACTIONBAR2BUTTON", 1, 12);
	scan_keys("MultiBarRightButton", "MULTIACTIONBAR3BUTTON", 1, 12);
	scan_keys("MultiBarLeftButton", "MULTIACTIONBAR4BUTTON", 1, 12);
	scan_keys("MultiBar5Button", "MULTIACTIONBAR5BUTTON", 1, 12);
	scan_keys("MultiBar6Button", "MULTIACTIONBAR6BUTTON", 1, 12);
	scan_keys("MultiBar7Button", "MULTIACTIONBAR7BUTTON", 1, 12);
	scan_keys("BonusActionButton", "ACTIONBUTTON", 1, 12);
	scan_keys("ExtraActionButton", "EXTRAACTIONBUTTON", 1, 12);
	scan_keys("VehicleMenuBarActionButton", "ACTIONBUTTON", 1, 12);
	scan_keys("OverrideActionBarButton", "ACTIONBUTTON", 1, 12);
	scan_keys("PetActionButton", "BONUSACTIONBUTTON", 1, 10);
end

-- Do the work
local function init()
	check_hotkeys();
	for _, viewer in ipairs(viewers) do
		if viewer then
			update_buttons(viewer)

			-- Hook Layout to reapply when Blizzard updates
			if viewer.Layout then
				hooksecurefunc(viewer, "Layout", function()
					add_todolist(viewer)
				end)
			end

			-- Hook Show/Hide to reapply when icons appear/disappear
			local children = { viewer:GetChildren() }
			for _, child in ipairs(children) do
				child:HookScript("OnShow", function()
					add_todolist(viewer)
				end)
				child:HookScript("OnHide", function()
					add_todolist(viewer)
				end)
			end
		end
	end
end

local function set_viewersalpha(alpha)
	for _, viewer in ipairs(viewers) do
		viewer:SetAlpha(alpha);
	end
end


local bfirst = true;
local function on_event(self, event, arg)
	if bfirst then
		bfirst = false;
		ns.setup_option();
	end

	if event == "ADDON_LOADED" and arg == "Blizzard_CooldownManager" then
		C_Timer.After(0.5, init);
	elseif event == "PLAYER_REGEN_DISABLED" then
		if ns.options.CombatAlphaChange then
			set_viewersalpha(configs.combatalpha);
		end
	elseif event == "PLAYER_REGEN_ENABLED" then
		if ns.options.CombatAlphaChange then
			set_viewersalpha(configs.normalalpha);
		end
	else
		C_Timer.After(0.5, init);

		if ns.options.CombatAlphaChange then
			if UnitAffectingCombat("player") then
				set_viewersalpha(configs.combatalpha);
			else
				set_viewersalpha(configs.normalalpha);
			end
		end
	end
end

main_frame:RegisterEvent("ADDON_LOADED");
main_frame:RegisterEvent("PLAYER_ENTERING_WORLD");
main_frame:RegisterEvent("PLAYER_REGEN_DISABLED");
main_frame:RegisterEvent("PLAYER_REGEN_ENABLED");
main_frame:RegisterEvent("UPDATE_BINDINGS");
main_frame:RegisterEvent("TRAIT_CONFIG_UPDATED");
main_frame:RegisterEvent("TRAIT_CONFIG_LIST_UPDATED");
main_frame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED");
main_frame:SetScript("OnEvent", on_event);
