local _, ns = ...;
local version = select(4, GetBuildInfo());
--[[
https://m.blog.naver.com/PostView.naver?blogId=relaxxlife&logNo=222914521011&proxyReferer=https:%2F%2Fwww.google.com%2F&trackingCode=external
- 0~2 : topleft, top, topright.
- 3~5 : left, center, right.
- 6~8 : bottomleft, bottom, bottomright.

1 39
0 0 0 7 7 UIParent 0.0 10.0 -1 ##$$%/&%'%)#+#,$             MainMenuBar
0 1 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&%'%(#,$               MultiBarBottomLeft
0 2 0 6 7 UIParent 0.0 60.0 -1 ##$%%/&$'%(#,#               MultiBarBottomRight
0 3 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$             MultiBarRight
0 4 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$             MultiBarLeft
0 5 0 7 7 UIParent 450.0 0.0 -1 ##$&%/&$'%(#,#              MultiBar5
0 6 0 7 7 UIParent -310.0 0.0 -1 ##$&%/&$'%(#,#             MultiBar6
0 7 0 7 7 UIParent 310.0 0.0 -1 ##$&%/&$'%(#,#              MultiBar7
0 10 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'%                    StanceBar
0 11 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'%,#                  PetActionBar
0 12 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'%                    PossessActionBar
1 -1 0 4 4 UIParent 0.0 -300.0 -1 ##$#%#                    PlayerCastingBarFrame
2 -1 1 2 2 UIParent 0.0 0.0 -1 ##$#%(                       MinimapCluster
3 0 0 5 4 UIParent -100.0 -220.0 -1 $#3#                    PlayerFrame
3 1 0 3 4 UIParent 100.0 -220.0 -1 %#3#                     TargetFrame
3 2 0 3 5 TargetFrame 0.0 0.0 -1 %#&#3#                     FocusFrame
3 3 0 2 4 UIParent -450.0 150.0 -1 '$(#)#-S.5/#1$3#         PartyFrame
3 4 0 0 6 UIParent 0.0 550.0 -1 ,%-;.-/#0#1#2(              CompactRaidFrameContainer
3 5 0 3 4 UIParent 300.0 0.0 -1 &$*$3#                      BossTargetFrameContainer
3 6 0 3 4 UIParent 300.0 0.0 -1 -#.#/#4&                    ArenaEnemyFramesContainer
3 7 0 1 6 PlayerFrame 0.0 -20.0 -1 3#                       PetFrame
4 -1 0 4 4 UIParent 0.0 -330.0 -1 #                         EncounterBar
5 -1 0 7 7 UIParent -310.0 80.0 -1 #                        ExtraAbilityContainer
6 0 1 2 2 UIParent -255.0 -10.0 -1 ##$#%#&.(()(             BuffFrame
6 1 1 2 2 UIParent -270.0 -155.0 -1 ##$#%#'+(()(            DebuffFrame
7 -1 0 0 0 UIParent 0.0 0.0 -1 #                            TalkingHeadFrame
8 -1 1 6 6 UIParent 0.0 0.0 -1 #'$A%$&7                     ChatFrame1
9 -1 1 7 7 UIParent 0.0 45.0 -1 #                           MainMenuBarVehicleLeaveButton
10 -1 1 0 0 UIParent 16.0 -116.0 -1 #                       LootFrame
11 -1 0 7 7 UIParent 500.0 50.0 -1 #                        GameTooltipDefaultContainer
12 -1 1 2 2 UIParent -110.0 -275.0 -1 #K$#%#                ObjectiveTrackerFrame
13 -1 1 8 8 MicroButtonAndBagsBar 0.0 0.0 -1 ##$#%)&-       MicroMenuContainer
14 -1 1 2 2 MicroButtonAndBagsBar 0.0 10.0 -1 ##$#%(        BagsBar
15 0 0 1 1 UIParent 0.0 0.0 -1 #                            MainStatusTrackingBarContainer
15 1 0 1 7 MainStatusTrackingBarContainer 0.0 -1.0 -1 #     SecondaryStatusTrackingBarContainer
16 -1 1 5 5 UIParent 0.0 0.0 -1 #(                          DurabilityFrame
17 -1 1 1 1 UIParent 0.0 -100.0 -1 ##                       MirrorTimerContainer
18 -1 1 5 5 UIParent 0.0 0.0 -1 #-                          VehicleSeatIndicator
19 -1 0 1 7 PlayerCastingBarFrame 0.0 -1.0 -1 ##            ArcheologyDigsiteProgressBar

--11.1.5
1 43
0 0 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&('%)#+#,$
0 1 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&('%(#,$
0 2 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&('%(#,$
0 3 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&('%(#,$
0 4 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&('%(#,$
0 5 1 1 4 UIParent 0.0 0.0 -1 ##$$%/&('%(#,$
0 6 1 1 4 UIParent 0.0 -50.0 -1 ##$$%/&('%(#,$
0 7 1 1 4 UIParent 0.0 -100.0 -1 ##$$%/&('%(#,$
0 10 1 7 7 UIParent 0.0 45.0 -1 ##$$&('%
0 11 1 7 7 UIParent 0.0 45.0 -1 ##$$&('%,#
0 12 1 7 7 UIParent 0.0 45.0 -1 ##$$&('%
1 -1 1 4 4 UIParent 0.0 0.0 -1 ##$#%#
2 -1 1 2 2 UIParent 0.0 0.0 -1 ##$#%(
3 0 1 8 7 UIParent -300.0 250.0 -1 $#3#
3 1 1 6 7 UIParent 300.0 250.0 -1 %#3#
3 2 1 6 7 UIParent 520.0 265.0 -1 %#&#3#
3 3 1 0 2 CompactRaidFrameManager 0.0 -7.0 -1 '#(#)#-#.#/#1$3#
3 4 1 0 2 CompactRaidFrameManager 0.0 -5.0 -1 ,#-#.#/#0#1#2(
3 5 1 5 5 UIParent 0.0 0.0 -1 &#*$3#
3 6 1 5 5 UIParent 0.0 0.0 -1 -#.#/#4$
3 7 1 4 4 UIParent 0.0 0.0 -1 3#
4 -1 1 7 7 UIParent 0.0 45.0 -1 #
5 -1 1 7 7 UIParent 0.0 45.0 -1 #
6 0 1 2 2 UIParent -255.0 -10.0 -1 ##$#%#&.(()(
6 1 1 2 2 UIParent -270.0 -155.0 -1 ##$#%#'+(()(
7 -1 1 7 7 UIParent 0.0 45.0 -1 #
8 -1 0 6 6 UIParent 35.0 50.0 -1 #'$A%$&7
9 -1 1 7 7 UIParent 0.0 45.0 -1 #
10 -1 1 0 0 UIParent 16.0 -116.0 -1 #
11 -1 1 8 8 UIParent -9.0 85.0 -1 #
12 -1 1 2 2 UIParent -110.0 -275.0 -1 #K$#%#
13 -1 1 8 8 MicroButtonAndBagsBar 0.0 0.0 -1 ##$#%)&-
14 -1 1 2 2 MicroButtonAndBagsBar 0.0 10.0 -1 ##$#%(
15 0 1 7 7 StatusTrackingBarManager 0.0 0.0 -1 #
15 1 1 7 7 StatusTrackingBarManager 0.0 17.0 -1 #
16 -1 1 5 5 UIParent 0.0 0.0 -1 #(
17 -1 1 1 1 UIParent 0.0 -100.0 -1 ##
18 -1 1 5 5 UIParent 0.0 0.0 -1 #-
19 -1 1 7 7 UIParent 0.0 0.0 -1 ##

--11.1.5
20 0 1 7 7 UIParent 0.0 310.0 -1 ##$)%$&%'%(-($)#+$,$
20 1 1 7 7 UIParent 0.0 240.0 -1 ##$*%$&''%(-($)#+$,$
20 2 1 7 7 UIParent 0.0 370.0 -1 ##$$%$&%'((-($)#+$,$
20 3 0 6 0 TargetFrame 20.0 -14.0 -1 #$$$%#&('((-($)#*#+$,$

1 43 0 0 0 7 7 UIParent 0.0 10.0 -1 ##$$%/&%'%)#+#,$ 0 1 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&%'%(#,$ 0 2 0 6 7 UIParent 28.0 77.0 -1 ##$%%/&$'%(#,# 0 3 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$ 0 4 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$ 0 5 0 7 7 UIParent 440.0 0.0 -1 ##$&%/&$'%(#,# 0 6 0 7 7 UIParent -315.0 0.0 -1 ##$&%/&$'%(#,# 0 7 0 7 7 UIParent 315.0 0.0 -1 ##$&%/&$'%(#,# 0 10 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'% 0 11 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'%,# 0 12 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'% 1 -1 0 4 4 UIParent 0.0 -300.0 -1 ##$#%# 2 -1 1 2 2 UIParent 0.0 0.0 -1 ##$#%( 3 0 0 5 4 UIParent -100.0 -225.0 -1 $#3# 3 1 0 3 4 UIParent 100.0 -225.0 -1 %#3# 3 2 0 3 5 TargetFrame -30.0 0.0 -1 %#&#3# 3 3 0 0 0 UIParent 338.2 -357.0 -1 '$(#)#-S.5/#1$3# 3 4 0 0 0 UIParent 0.0 -524.0 -1 ,%-;.-/#0#1#2( 3 5 0 2 2 UIParent -328.2 -359.5 -1 &$*$3# 3 6 0 2 2 UIParent -315.2 -451.0 -1 -#.#/#4& 3 7 0 1 6 PlayerFrame 20.0 10.0 -1 3# 4 -1 0 4 4 UIParent 0.0 -330.0 -1 # 5 -1 0 7 7 UIParent -310.0 80.0 -1 # 6 0 1 2 2 UIParent -255.0 -10.0 -1 ##$#%#&.(()( 6 1 1 2 2 UIParent -270.0 -155.0 -1 ##$#%#'+(()( 7 -1 0 0 0 UIParent 0.0 0.0 -1 # 8 -1 1 6 6 UIParent 0.0 0.0 -1 #'$A%$&7 9 -1 1 7 7 UIParent 0.0 45.0 -1 # 10 -1 1 0 0 UIParent 16.0 -116.0 -1 # 11 -1 0 7 7 UIParent 500.0 50.0 -1 # 12 -1 1 2 2 UIParent -110.0 -275.0 -1 #K$#%# 13 -1 1 8 8 MicroButtonAndBagsBar 0.0 0.0 -1 ##$#%)&- 14 -1 1 2 2 MicroButtonAndBagsBar 0.0 10.0 -1 ##$#%( 15 0 0 1 1 UIParent 0.0 0.0 -1 # 15 1 0 1 7 MainStatusTrackingBarContainer 0.0 -1.0 -1 # 16 -1 1 5 5 UIParent 0.0 0.0 -1 #( 17 -1 1 1 1 UIParent 0.0 -100.0 -1 ## 18 -1 1 5 5 UIParent 0.0 0.0 -1 #- 19 -1 0 1 7 PlayerCastingBarFrame 0.0 -15.0 -1 ## 20 0 1 7 7 UIParent 0.0 290.0 -1 ##$)%$&%'%(-($)#+$,$ 20 1 1 7 7 UIParent 0.0 230.0 -1 ##$*%$&''%(-($)#+$,$ 20 2 1 7 7 UIParent 0.0 370.0 -1 ##$$%$&%'((-($)#+$,$ 20 3 0 8 2 PlayerFrame -18.0 -12.0 -1 #$$$%#&&'((U)#*#+$,$

1 43 0 0 0 7 7 UIParent 0.0 10.0 -1 ##$$%/&%'%)#+#,$ 0 1 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&%'%(#,$ 0 2 0 6 7 UIParent 28.0 77.0 -1 ##$%%/&$'%(#,# 0 3 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$ 0 4 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$ 0 5 0 7 7 UIParent 440.0 0.0 -1 ##$&%/&$'%(#,# 0 6 0 7 7 UIParent -315.0 0.0 -1 ##$&%/&$'%(#,# 0 7 0 7 7 UIParent 315.0 0.0 -1 ##$&%/&$'%(#,# 0 10 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'% 0 11 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'%,# 0 12 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'% 1 -1 0 4 4 UIParent 0.0 -300.0 -1 ##$#%# 2 -1 1 2 2 UIParent 0.0 0.0 -1 ##$#%( 3 0 0 5 4 UIParent -100.0 -225.0 -1 $#3# 3 1 0 3 4 UIParent 100.0 -225.0 -1 %#3# 3 2 0 3 5 TargetFrame -30.0 0.0 -1 %#&#3# 3 3 0 0 0 UIParent 338.2 -357.0 -1 '$(#)#-S.5/#1$3# 3 4 0 0 0 UIParent 0.0 -524.0 -1 ,%-;.-/#0#1#2( 3 5 0 2 2 UIParent -328.2 -359.5 -1 &$*$3# 3 6 0 2 2 UIParent -315.2 -451.0 -1 -#.#/#4& 3 7 0 1 6 PlayerFrame 20.0 10.0 -1 3# 4 -1 0 4 4 UIParent 0.0 -330.0 -1 # 5 -1 0 7 7 UIParent -310.0 80.0 -1 # 6 0 1 2 2 UIParent -255.0 -10.0 -1 ##$#%#&.(()( 6 1 1 2 2 UIParent -270.0 -155.0 -1 ##$#%#'+(()( 7 -1 0 0 0 UIParent 0.0 0.0 -1 # 8 -1 1 6 6 UIParent 0.0 0.0 -1 #'$A%$&7 9 -1 1 7 7 UIParent 0.0 45.0 -1 # 10 -1 1 0 0 UIParent 16.0 -116.0 -1 # 11 -1 0 7 7 UIParent 500.0 50.0 -1 # 12 -1 1 2 2 UIParent -110.0 -275.0 -1 #K$#%# 13 -1 1 8 8 MicroButtonAndBagsBar 0.0 0.0 -1 ##$#%)&- 14 -1 1 2 2 MicroButtonAndBagsBar 0.0 10.0 -1 ##$#%( 15 0 0 1 1 UIParent 0.0 0.0 -1 # 15 1 0 1 7 MainStatusTrackingBarContainer 0.0 -1.0 -1 # 16 -1 1 5 5 UIParent 0.0 0.0 -1 #( 17 -1 1 1 1 UIParent 0.0 -100.0 -1 ## 18 -1 1 5 5 UIParent 0.0 0.0 -1 #- 19 -1 0 1 7 PlayerCastingBarFrame 0.0 -15.0 -1 ## 20 0 0 4 4 UIParent 0.0 -232.7 -1 ##$)%$&&'%(-($)#+$,$-$ 20 1 0 1 7 EssentialCooldownViewer 0.0 -4.0 -1 ##$*%$&''%(-($)#+$,$-$ 20 2 0 4 4 UIParent 0.0 -151.0 -1 ##$$%$&)'((-($)#+$,$-$ 20 3 0 8 2 PlayerFrame -18.0 -12.0 -1 #$$$%#&&'((U)#*#+$,$-$
]]

ns.layout =
"2 50 0 0 0 7 7 UIParent 0.0 10.0 -1 ##$$%/&%'%)#+#,$ 0 1 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&%'%(#,$ 0 2 0 6 7 UIParent 28.0 77.0 -1 ##$%%/&$'%(#,# 0 3 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$ 0 4 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&%'%(#,$ 0 5 0 7 7 UIParent 440.0 0.0 -1 ##$&%/&$'%(#,# 0 6 0 7 7 UIParent -315.0 0.0 -1 ##$&%/&$'%(#,# 0 7 0 7 7 UIParent 315.0 0.0 -1 ##$&%/&$'%(#,# 0 10 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'% 0 11 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'%,# 0 12 1 7 7 UIParent 0.0 45.0 -1 ##$$&%'% 1 -1 0 0 0 UIParent 817.2 -763.5 -1 ##$#%# 2 -1 1 2 2 UIParent 0.0 0.0 -1 ##$#%( 3 0 0 5 4 UIParent -100.0 -225.0 -1 $#3# 3 1 0 3 4 UIParent 100.0 -225.0 -1 %#3# 3 2 0 3 5 TargetFrame -30.0 0.0 -1 %#&#3# 3 3 0 0 0 UIParent 458.2 -357.0 -1 '$(#)#-S.5/#1$3#5#6*7-7$ 3 4 0 0 0 UIParent 0.0 -524.0 -1 ,%-;.-/#0#1#2(5#6*7-7$ 3 5 0 2 2 UIParent -328.2 -359.5 -1 &$*$3# 3 6 0 2 2 UIParent -308.2 -483.5 -1 -#.#/#4&5#6-6$7-7$ 3 7 0 1 6 PlayerFrame 20.0 10.0 -1 3# 4 -1 0 4 4 UIParent 0.0 -330.0 -1 # 5 -1 0 7 7 UIParent -310.0 80.0 -1 # 6 0 1 2 2 UIParent -255.0 -10.0 -1 ##$#%#&.(()( 6 1 1 2 2 UIParent -270.0 -155.0 -1 ##$#%#'+(()( 6 2 0 8 2 BuffBarCooldownViewer 0.0 4.0 -1 ##$#%#&.(()(+#,-,$ 7 -1 0 1 1 UIParent -623.2 -2.0 -1 # 8 -1 1 6 6 UIParent 0.0 0.0 -1 #'$A%$&7 9 -1 1 7 7 UIParent 0.0 45.0 -1 # 10 -1 1 0 0 UIParent 16.0 -116.0 -1 # 11 -1 0 7 7 UIParent 500.0 50.0 -1 # 12 -1 1 2 2 UIParent -110.0 -275.0 -1 #K$#%# 13 -1 1 8 8 MicroButtonAndBagsBar 0.0 0.0 -1 ##$#%)&- 14 -1 1 2 2 MicroButtonAndBagsBar 0.0 10.0 -1 ##$#%( 15 0 0 1 1 UIParent 0.0 0.0 -1 # 15 1 0 1 7 MainStatusTrackingBarContainer 0.0 -1.0 -1 # 16 -1 1 5 5 UIParent 0.0 0.0 -1 #( 17 -1 1 1 1 UIParent 0.0 -100.0 -1 ## 18 -1 1 5 5 UIParent 0.0 0.0 -1 #- 19 -1 0 1 7 PlayerCastingBarFrame 0.0 -15.0 -1 ## 20 0 0 0 0 UIParent 786.2 -727.3 -1 ##$7%$&&'%(-($)#+$,$-$ 20 1 0 0 0 UIParent 785.0 -801.4 -1 ##$-%$&&'%(-($)#+$,$-$ 20 2 0 0 0 UIParent 789.2 -661.0 -1 ##$$%$&&'((-($)#+$,$-$ 20 3 0 7 7 UIParent -210.0 374.0 -1 #$$$%#&&'((U)#*#+$,$-$.U 21 -1 0 4 4 UIParent 0.0 -219.6 -1 ##$# 22 0 0 6 0 FocusFrame 15.1 -8.9 -1 #$$$%#&('%(#)U*$+$,$ 22 1 1 1 1 UIParent 0.0 -215.0 -1 &('()U*#+$ 22 2 1 1 1 UIParent 0.0 -270.0 -1 &('()U*#+$ 22 3 1 1 1 UIParent 0.0 -315.0 -1 &('()U*#+$ 23 -1 0 7 7 UIParent 756.7 2.0 -1 ##$#%#&#'A(#)U*#+$,$-,.("
