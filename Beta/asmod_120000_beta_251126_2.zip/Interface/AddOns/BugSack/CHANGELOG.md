# BugSack

## [v11.2.8](https://github.com/funkydude/BugSack/tree/v11.2.8) (2025-11-21)
[Full Changelog](https://github.com/funkydude/BugSack/compare/v11.2.7...v11.2.8) [Previous Releases](https://github.com/funkydude/BugSack/releases)

- Bump version  
