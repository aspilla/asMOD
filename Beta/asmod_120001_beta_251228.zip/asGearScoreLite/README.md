# asGearScoreLite (Mid Night)

Displays item levels in the Character and Inspect windows.
![asGearScoreLite](https://github.com/aspilla/asMOD/blob/main/.Pictures/asGearScoreLite.jpg?raw=true)

## Key Features

*   **Individual Item Level Display**:
    *   **Character Window**: 
    *   **Inspect Window**: 

*   **Target's Average Item Level (Top right of Inspect Window)**:

## Configuration
No configuration options.

---

# asGearScoreLite (한밤)

자신의 캐릭터 창 및 살펴보기 창에 아이템 레벨을 표시
![asGearScoreLite](https://github.com/aspilla/asMOD/blob/main/.Pictures/asGearScoreLite.jpg?raw=true)

## 주요 기능

*   **개별 아이템 레벨 표시**:
    *   **캐릭터 창**: 
    *   **살펴보기 창**: 

*   **대상의 평균 아이템 레벨 (살펴보기 창 우 상단)**:

## 설정
없음