# asCastBar (Mid Night)

Displays an icon and cast time on the default player cast bar.
![asCastBar](https://github.com/aspilla/asMOD/blob/main/.Pictures/asCastBar.jpg?raw=true)

## Main Features

1.  **Spell Icon Display**:
2.  **Cast Timer**:
    *   `Current_Cast_Time / Total_Cast_Time`

---

# asCastBar (한밤)

기본 플레이어 시전 바에 아이콘과 시전시간 표시
![asCastBar](https://github.com/aspilla/asMOD/blob/main/.Pictures/asCastBar.jpg?raw=true)


## 주요 기능

1.  **주문 아이콘 표시**:
2.  **시전 타이머**:
    *   `현재_시전_시간 / 총_시전_시간`
