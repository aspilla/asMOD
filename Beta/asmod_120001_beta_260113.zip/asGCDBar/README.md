# asGCDBar (Midnight)

Simple status bar to visualize the player's Global Cooldown (GCD)
![asGCDBar](https://github.com/aspilla/asMOD/blob/main/.Pictures/asGCDBar.jpg?raw=true)

## Configuration
* **Move Position**: Enter the `/asConfig` command in the chat.
* **Reset Position**: Enter the `/asClear` command in the chat to restore default settings.

---

# asGCDBar (한밤)

전역 재사용 대기시간(GCD) 표시 바
![asGCDBar](https://github.com/aspilla/asMOD/blob/main/.Pictures/asGCDBar.jpg?raw=true)

## 설정
*  **위치 이동** : `/asConfig` 명령어 채팅창에 입력
*  **위치 초기화** : `/asClear` 명령어 채팅창에 입력, 기본 설정으로 초기화 
