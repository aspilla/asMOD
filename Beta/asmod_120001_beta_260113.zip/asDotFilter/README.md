# asDotFilter (Midnight)

Debuff tracker for boss and focus

![asDotFilter](https://github.com/aspilla/asMOD/blob/main/.Pictures/asDotFilter.jpg?raw=true)

## Main Features

1.  **Track Player-Cast Debuffs**
2.  **Supports WoW's Default Boss Frames/Focus Frames**
3.  **Supports asUnitFrame**

## User Settings

No settings available.

---

# asDotFilter (한밤)

보스/주시 디버프를 추적

![asDotFilter](https://github.com/aspilla/asMOD/blob/main/.Pictures/asDotFilter.jpg?raw=true)

## 주요 기능

1.  **플레이어 시전 Debuff 추적**    
2.  **와우 기본 보스 프레임/주시 프레임 지원**
3.  **asUnitFrame 지원**

## 사용자 설정

설정 없음
