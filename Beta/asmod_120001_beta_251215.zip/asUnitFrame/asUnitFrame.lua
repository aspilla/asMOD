---@diagnostic disable: undefined-field
local _, ns = ...;

------------------------------------------
---Config
------------------------------------------

local Update_Rate = 0.1
local config_width = 200;
local xposition = 225;
local yposition = -198;
local healthheight = 35;
local powerheight = 5;
local buffcount = 4;
local buffsize = 25;

local CONFIG_FONT = STANDARD_TEXT_FONT;
local region = GetCurrentRegion();

if region == 2 and GetLocale() ~= "koKR" then
    CONFIG_FONT = "Fonts\\2002.ttf";
end

local leaderIcon = CreateAtlasMarkup("groupfinder-icon-leader", 14, 9, 0, 0);
local combatIcon = CreateAtlasMarkup("pvptalents-warmode-swords", 14, 14);
local restingIcon = CreateAtlasMarkup("Innkeeper", 14, 14);
local eliteIcon = CreateAtlasMarkup("nameplates-icon-elite-gold", 14, 14);
local rareIcon = CreateAtlasMarkup("UI-HUD-UnitFrame-Target-PortraitOn-Boss-Rare-Star", 14, 14);
local rareeliteIcon = CreateAtlasMarkup("nameplates-icon-elite-silver", 14, 14);

local function UpdateFillBarBase(realbar, bar, amount, bleft, pointbar, totalMax)
    if not amount or (amount == 0) then
        bar:Hide();
        return
    end

    local previousTexture = pointbar;

    if previousTexture == nil then
        previousTexture = realbar:GetStatusBarTexture();
    end

    bar:ClearAllPoints();
    if bleft then
        bar:SetPoint("TOPLEFT", previousTexture, "TOPLEFT", 0, 0);
        bar:SetPoint("BOTTOMLEFT", previousTexture, "BOTTOMLEFT", 0, 0);
    else
        bar:SetPoint("TOPLEFT", previousTexture, "TOPRIGHT", 0, 0);
        bar:SetPoint("BOTTOMLEFT", previousTexture, "BOTTOMRIGHT", 0, 0);
    end

    local totalWidth, totalHeight = realbar:GetSize();    

    local barSize = (amount / totalMax) * totalWidth;
    bar:SetWidth(barSize);
    bar:Show();
end

local unit_player = "player";
local unit_pet = "pet";

local function UpdatePlayerUnit()
    local hasValidVehicleUI = UnitHasVehicleUI("player");
    local unitVehicleToken;
    if (hasValidVehicleUI) then
        local prefix, id, suffix = string.match("player", "([^%d]+)([%d]*)(.*)")
        unitVehicleToken = prefix .. "pet" .. id .. suffix;
        if (not UnitExists(unitVehicleToken)) then
            hasValidVehicleUI = false;
        end
    end

    if (hasValidVehicleUI) then
        unit_player = unitVehicleToken
        unit_pet = "player"
    else
        unit_player = "player"
        unit_pet = "pet"
    end
end

local curve = C_CurveUtil.CreateCurve();
curve:SetType(Enum.LuaCurveType.Linear);
curve:AddPoint(0, 0);
curve:AddPoint(1, 100);

local function updateUnit(frame)
    local unit = frame.unit;
    local showplayermana = false;

    if unit == "player" then
        UpdatePlayerUnit()
        unit = unit_player;
        showplayermana = (unit ~= "player");

        if not InCombatLockdown() and unit ~= frame:GetAttribute("unit") then
            frame:SetAttribute("unit", unit);
        end
    elseif unit == "pet" then
        unit = unit_pet;
    end

    if not UnitExists(unit) then
        return;
    else
    end

    -- Healthbar
    local value = UnitHealth(unit);
    local valueMax = UnitHealthMax(unit);
    --local value_orig = value;
    --local allIncomingHeal = UnitGetIncomingHeals(unit) or 0;
    --local totalAbsorb = UnitGetTotalAbsorbs(unit) or 0;
    local valuePct = UnitHealthPercent(unit, false, curve);
    --    local valuePct_orig = (math.ceil((value_orig / valueMax) * 100));
    -- local valuePctAbsorb = (math.ceil((total / valueMax) * 100));

    frame.healthbar:SetMinMaxValues(0, valueMax)
    frame.healthbar:SetValue(value, Enum.StatusBarInterpolation.ExponentialEaseOut)

    if UnitIsDead(unit) then
        frame.healthbar.pvalue:SetText("Dead");
        --elseif valuePctAbsorb > 0 then
        --  frame.healthbar.pvalue:SetText(valuePct .. "(" .. valuePctAbsorb .. ")");
    else
        frame.healthbar.pvalue:SetText(string.format("%d", valuePct));        
    end

    --[[
    local totalAbsorbremain = totalAbsorb;
    local remainhealth = valueMax - value;
    local remainhealthAfterHeal = remainhealth - allIncomingHeal;
    local incominghealremain = allIncomingHeal;

    if allIncomingHeal > remainhealth then
        incominghealremain = remainhealth;
    end

    if remainhealthAfterHeal < 0 then
        remainhealthAfterHeal = 0
    end

    if totalAbsorbremain > remainhealthAfterHeal then
        totalAbsorbremain = remainhealthAfterHeal;
    end
    local pointbar = nil

    UpdateFillBarBase(frame.healthbar, frame.healthbar.incominghealBar, incominghealremain, false, nil);

    if frame.healthbar.incominghealBar:IsShown() then
        pointbar = frame.healthbar.incominghealBar;
    end

    UpdateFillBarBase(frame.healthbar, frame.healthbar.absorbBar, totalAbsorbremain, false, pointbar);

    if frame.healthbar.absorbBar:IsShown() then
        frame.healthbar.absorbBarO:Show()
    else
        frame.healthbar.absorbBarO:Hide()
    end

    local remainAbsorb = totalAbsorb - totalAbsorbremain;

    if remainAbsorb > valueMax then
        remainAbsorb = valueMax;
    end

    UpdateFillBarBase(frame.healthbar, frame.healthbar.shieldBar, remainAbsorb, true, nil);
    ]]

    --CastBar
    if frame.updateCastBar then
        ns.updateCastBar(frame.castbar);
    end

    if frame.updatecount == 1 then
        frame.updatecount = 0;
    else
        frame.updatecount = frame.updatecount + 1;
        return;
    end

    local role = UnitGroupRolesAssigned(unit);

    --ClassColor
    if UnitIsPlayer(unit) or (role and role ~= "NONE") then
        local class = select(2, UnitClass(unit));
        local classColor = class and RAID_CLASS_COLORS[class] or nil;
        if classColor then
            frame.healthbar:SetStatusBarColor(classColor.r, classColor.g, classColor.b);
        end
    else
        local r = 0;
        local g = 1.0;
        local b = 0;
        local reaction = UnitReaction("player", unit);
        if (reaction) then
            r = FACTION_BAR_COLORS[reaction].r;
            g = FACTION_BAR_COLORS[reaction].g;
            b = FACTION_BAR_COLORS[reaction].b;
        end

        frame.healthbar:SetStatusBarColor(r, g, b);
    end


    local raidicon = GetRaidTargetIndex(unit)

    --Name
    local leveltext = ""
    local unitlevel = UnitLevel(unit);
    if unitlevel < 0 then
        leveltext = "??"
    else
        leveltext = tostring(unitlevel);
    end
    local name = UnitName(unit);

    if not frame.is_small then
        name = leveltext .. " " .. name;
    end

    -- Type
    local classtext = "";

    local classification = UnitClassification(unit)

    if (classification == "elite" or classification == "worldboss") then
        classtext = eliteIcon;
    elseif (classification == "rare") then
        classtext = rareIcon;
    elseif (classification == "rareelite") then
        classtext = rareeliteIcon;
    end

    if frame == AUF_PlayerFrame or frame == AUF_TargetFrame then
        if UnitIsGroupLeader(unit) then
            classtext = classtext .. leaderIcon;
        end

        if (role and role ~= "NONE") then
            local texture = nil;
            if (role == "TANK") then
                texture = CreateAtlasMarkup("roleicon-tiny-tank");
            elseif (role == "DAMAGER") then
                texture = CreateAtlasMarkup("roleicon-tiny-dps");
            elseif (role == "HEALER") then
                texture = CreateAtlasMarkup("roleicon-tiny-healer");
            end

            if texture then
                classtext = classtext .. texture;
            end
        end


        if UnitAffectingCombat(unit) then
            classtext = classtext .. combatIcon;
        end

        if IsResting() and frame == AUF_PlayerFrame then
            classtext = classtext .. restingIcon;
        end

        --[[
        local creatureType = UnitCreatureType(unit)

        if creatureType and not UnitIsPlayer(unit) then
            classtext = classtext .. " (" .. creatureType .. ")";
        end
        ]]
    end

    frame.healthbar.hvalue:SetText(AbbreviateLargeNumbers(value))
    frame.healthbar.name:SetText(name);
    frame.healthbar.mark:SetText(raidicon);
    frame.healthbar.classtext:SetText(classtext);

    --Power
    local power = UnitPower(unit)
    local maxPower = UnitPowerMax(unit)
    frame.powerbar:SetMinMaxValues(0, maxPower)
    frame.powerbar:SetValue(power)
    frame.powerbar.value:SetText(power)

    local powerType, powerToken = UnitPowerType(unit)

    if powerType ~= nil then
        local powerColor = PowerBarColor[powerType]
        if powerColor then
            frame.powerbar:SetStatusBarColor(powerColor.r, powerColor.g, powerColor.b)
        end

        if frame == AUF_PlayerFrame then
            if powerType > 0 then
                local manavalue = UnitPower(unit, 0);
                local manaMax = UnitPowerMax(unit, 0);

                if manaMax > 0 then
                    frame.powerbar:SetMinMaxValues(0, manaMax)
                    frame.powerbar:SetValue(manavalue);
                    frame.powerbar.value:SetText(manavalue)
                    local powerColor = PowerBarColor[0]
                    frame.powerbar:SetStatusBarColor(powerColor.r, powerColor.g, powerColor.b)
                    frame.powerbar:Show();
                elseif showplayermana then
                    frame.powerbar:Show();
                else
                    frame.powerbar:Hide();
                end
            else
                frame.powerbar:Hide();
            end
        end
    end

    --Target

    if ns.options.ShowTargetBorder and frame.bchecktarget then
        if UnitIsUnit(unit, "target") then
            frame.targetborder:Show();
        else
            frame.targetborder:Hide();
        end
    end

    --Threat
    if frame == AUF_TargetFrame and not UnitIsPlayer(unit) then
        local isTanking, status, percentage, rawPercentage = UnitDetailedThreatSituation("player", unit);

        local display;

        if (isTanking) then
            display = UnitThreatPercentageOfLead("player", unit);
        end

        if not display then
            display = percentage;
        end

        if (display and display ~= 0) then
            frame.healthbar.aggro:SetText(format("%1.0f", display) .. "%");
            local r, g, b = GetThreatStatusColor(status)
            frame.healthbar.aggro:SetTextColor(r, g, b, 1);
            frame.healthbar.aggro:Show();
        else
            frame.healthbar.aggro:Hide();
        end
    else
        frame.healthbar.aggro:Hide();
    end

    if frame.portrait then
        SetPortraitTexture(frame.portrait.portrait, unit, false);
    end

    if UnitAffectingCombat("player") then
        frame:SetAlpha(1);
    else
        frame:SetAlpha(0.5);
    end
end

local function asTargetFrame_OpenMenu(self, unit)
    local which;
    local name;

    if issecretvalue(unit) then
        return;
    end

    if (UnitIsUnit(unit, "player")) then
        which = "SELF";
    elseif (UnitIsUnit(unit, "vehicle")) then
        -- NOTE: vehicle check must come before pet check for accuracy's sake because
        -- a vehicle may also be considered your pet
        which = "VEHICLE";
    elseif (UnitIsUnit(unit, "pet")) then
        which = "PET";
    elseif (UnitIsOtherPlayersBattlePet(unit)) then
        which = "OTHERBATTLEPET";
    elseif (UnitIsBattlePet(unit)) then
        which = "BATTLEPET";
    elseif (UnitIsOtherPlayersPet(unit)) then
        which = "OTHERPET";
    elseif (UnitIsPlayer(unit)) then
        if (UnitInRaid(unit)) then
            which = "RAID_PLAYER";
        elseif (UnitInParty(unit)) then
            which = "PARTY";
        else
            if (not UnitIsMercenary("player")) then
                if (UnitCanCooperate("player", unit)) then
                    which = "PLAYER";
                else
                    which = "ENEMY_PLAYER"
                end
            else
                if (UnitCanAttack("player", unit)) then
                    which = "ENEMY_PLAYER"
                else
                    which = "PLAYER";
                end
            end
        end
    else
        which = "TARGET";
        name = RAID_TARGET_ICON;
    end
    if (which) then
        local contextData = {
            fromTargetFrame = true,
            unit = unit,
            name = name,
        };

        UnitPopup_OpenMenu(which, contextData);
    end
end

local function OpenContextMenu(s, unit, button, isKeyPress)
    return asTargetFrame_OpenMenu(s, s.unit);
end

local function UpdateDebuffAnchor(frames, index, offsetX, right, parent, width)
    local buff = frames[index];

    if (index == 1) then
        buff:SetPoint("TOPLEFT", parent.healthbar, "BOTTOMLEFT", 0, -(powerheight / 2 + 2));
    else
        buff:SetPoint("BOTTOMLEFT", frames[index - 1], "BOTTOMRIGHT", offsetX, 0);
    end

    -- Resize
    buff:SetWidth(width - offsetX);
    buff:SetHeight(width * 0.8);
end

local function CreateDebuffFrames(parent, bright, fontsize, width, count)
    if parent.debuffframes == nil then
        parent.debuffframes = {};
    end

    for idx = 1, count do
        parent.debuffframes[idx] = CreateFrame("Button", nil, parent, "AUFDebuffFrameTemplate");
        local frame = parent.debuffframes[idx];

        frame.cooldown:SetDrawSwipe(true);
        for _, r in next, { frame.cooldown:GetRegions() } do
            if r:GetObjectType() == "FontString" then
                r:SetFont(STANDARD_TEXT_FONT, fontsize, "OUTLINE");
                r:ClearAllPoints();
                r:SetPoint("CENTER", 0, 0);
                r:SetDrawLayer("OVERLAY");
                break
            end
        end

        frame.count:SetFont(STANDARD_TEXT_FONT, fontsize, "OUTLINE")
        frame.count:ClearAllPoints()
        frame.count:SetPoint("BOTTOMRIGHT", frame.icon, "BOTTOMRIGHT", -2, 2);

        frame.icon:SetTexCoord(.08, .92, .16, .84);
        frame.icon:SetAlpha(1);


        frame.border:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
        frame.border:SetVertexColor(0, 0, 0);
        frame.border:SetAlpha(1);

        frame:ClearAllPoints();
        UpdateDebuffAnchor(parent.debuffframes, idx, 1, bright, parent, width / count);

        frame:EnableMouse(false);
        frame:Hide();
    end

    return;
end

local function UpdateBuffAnchor(frames, index, offsetX, right, parent, width)
    local buff = frames[index];

    if (index == 1) then
        buff:SetPoint("RIGHT", parent.healthbar, "LEFT", -offsetX, 0);
    else
        buff:SetPoint("RIGHT", frames[index - 1], "LEFT", -offsetX, 0);
    end

    -- Resize
    buff:SetWidth(width - offsetX);
    buff:SetHeight(width * 0.8);
end

local function CreateBuffFrames(parent, bright, fontsize, width, count)
    if parent.buffframes == nil then
        parent.buffframes = {};
    end

    for idx = 1, count do
        parent.buffframes[idx] = CreateFrame("Button", nil, parent, "AUFDebuffFrameTemplate");
        local frame = parent.buffframes[idx];

        frame.cooldown:SetDrawSwipe(true);
        for _, r in next, { frame.cooldown:GetRegions() } do
            if r:GetObjectType() == "FontString" then
                r:SetFont(STANDARD_TEXT_FONT, fontsize, "OUTLINE");
                r:ClearAllPoints();
                r:SetPoint("TOP", 0, 5);
                r:SetDrawLayer("OVERLAY");
                break
            end
        end

        frame.count:SetFont(STANDARD_TEXT_FONT, fontsize, "OUTLINE")
        frame.count:ClearAllPoints()
        frame.count:SetPoint("BOTTOMRIGHT", frame.icon, "BOTTOMRIGHT", -2, 2);

        frame.icon:SetTexCoord(.08, .92, .16, .84);
        frame.icon:SetAlpha(1);


        frame.border:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
        frame.border:SetVertexColor(1, 1, 1);
        frame.border:SetAlpha(1);

        frame:ClearAllPoints();
        UpdateBuffAnchor(parent.buffframes, idx, 2, bright, parent, width);

        frame:EnableMouse(false);
        frame:Hide();
    end

    return;
end

local function UpdateTotemAnchor(frames, index, offsetX, right, parent, width)
    local button = frames[index];

    if (index == 1) then
        button:SetPoint("TOPRIGHT", parent, "BOTTOMRIGHT", 0, -2);
    else
        button:SetPoint("BOTTOMRIGHT", frames[index - 1], "BOTTOMLEFT", -offsetX, 0);
    end

    -- Resize
    button:SetWidth(width);
    button:SetHeight(width * 0.8);
    button.Icon:SetWidth(width);
    button.Icon:SetHeight(width * 0.8);
end

local function CreatTotemFrames(parent, bright, fontsize, width, count)
    if parent.totembuttons == nil then
        parent.totembuttons = {};
    end

    for idx = 1, count do
        parent.totembuttons[idx] = CreateFrame("Button", nil, parent, "asTotemButtonTemplate");
        local button = parent.totembuttons[idx];
        local frame = button.Icon;

        frame.cooldown:SetDrawSwipe(true);
        for _, r in next, { frame.cooldown:GetRegions() } do
            if r:GetObjectType() == "FontString" then
                r:SetFont(STANDARD_TEXT_FONT, fontsize, "OUTLINE");
                r:ClearAllPoints();
                r:SetPoint("BOTTOM", 0, -5);
                r:SetDrawLayer("OVERLAY");
                break
            end
        end

        frame.icon:SetTexCoord(.08, .92, .16, .84);
        frame.icon:SetAlpha(1);

        frame.border:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
        frame.border:SetVertexColor(0, 0, 0);
        frame.border:SetAlpha(1);

        button:ClearAllPoints();
        UpdateTotemAnchor(parent.totembuttons, idx, 1, bright, parent, (width / 2 - 3) / count);
        frame:Show();
        button:SetAttribute("type", "destroytotem");
        button:SetAttribute("totem-slot", idx);
        button:SetAlpha(0);
        button:Show();
    end

    return;
end

ns.unitframes = {};

local function onUnitEvent(self, event, arg1, arg2)
    if event == "PLAYER_TOTEM_UPDATE" then
        ns.UpdateTotems(self);
    end
end

local function CreateUnitFrame(frame, unit, x, y, width, height, powerbarheight, fontsize, debuffupdate, is_small)
    local FontOutline = "OUTLINE";


    frame:ClearAllPoints();
    frame:SetPoint("CENTER", UIParent, "CENTER", x, y);
    frame:SetSize(width, height)
    frame:SetFrameStrata("LOW");
    frame:SetFrameLevel(900);
    frame.targetborder = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
    frame.targetborder:SetTexture("Interface\\Addons\\asUnitFrame\\border.tga")
    frame.targetborder:SetPoint("TOPLEFT", frame, "TOPLEFT", -2, 2);
    frame.targetborder:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 2, -2);
    frame.targetborder:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
    frame.targetborder:SetVertexColor(1, 1, 1)
    frame.targetborder:SetAlpha(1);
    frame.targetborder:Hide();

    frame.healthbar = CreateFrame("StatusBar", nil, frame);
    frame.healthbar:SetStatusBarTexture("Interface\\addons\\asUnitFrame\\UI-StatusBar")
    frame.healthbar:GetStatusBarTexture():SetHorizTile(false)
    frame.healthbar:SetMinMaxValues(0, 100)
    frame.healthbar:SetValue(100)
    frame.healthbar:SetHeight(height);
    frame.healthbar:Show();

    if x < 0 then
        frame.healthbar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0);
    else
        frame.healthbar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0);
    end

    local hwidth = width;

    if ns.options.ShowPortrait then
        hwidth = width - height * 1.1;

        frame.portrait = CreateFrame("Button", nil, frame, "AUFDebuffFrameTemplate");
        local pframe = frame.portrait;
        pframe.cooldown:SetDrawSwipe(true);
        for _, r in next, { pframe.cooldown:GetRegions() } do
            if r:GetObjectType() == "FontString" then
                r:SetFont(STANDARD_TEXT_FONT, fontsize, "OUTLINE");
                r:ClearAllPoints();
                r:SetPoint("CENTER", 0, 0);
                r:SetDrawLayer("OVERLAY");
                break
            end
        end

        pframe.count:SetFont(STANDARD_TEXT_FONT, fontsize, "OUTLINE")
        pframe.count:ClearAllPoints()
        pframe.count:SetPoint("BOTTOMRIGHT", pframe.icon, "BOTTOMRIGHT", -2, 2);

        pframe.portrait:SetTexCoord(.08, .92, .08, .92);
        pframe.portrait:SetAlpha(1);
        pframe.icon:SetTexCoord(.08, .92, .08, .92);
        pframe.icon:SetAlpha(1);
        pframe.border:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
        pframe.border:SetVertexColor(0, 0, 0)
        pframe.border:SetAlpha(1);

        pframe:SetSize(height * 1.1, height + 2);

        if x < 0 then
            pframe:SetPoint("TOPRIGHT", frame.healthbar, "TOPLEFT", 0, 1);
        else
            pframe:SetPoint("TOPLEFT", frame.healthbar, "TOPRIGHT", 0, 1);
        end
        pframe.portrait:Show();
        pframe:Show();
    end

    frame.healthbar:SetWidth(hwidth);

    frame.healthbar.predictionBar = frame.healthbar:CreateTexture(nil, "BORDER");
    frame.healthbar.predictionBar:SetTexture("Interface\\addons\\asUnitFrame\\UI-StatusBar");
    frame.healthbar.predictionBar:Hide();

    frame.healthbar.absorbBar = frame.healthbar:CreateTexture(nil, "BORDER");
    frame.healthbar.absorbBar:SetTexture("Interface\\RaidFrame\\Shield-Fill");
    frame.healthbar.absorbBar:SetAlpha(1);
    frame.healthbar.absorbBar:Hide();

    frame.healthbar.absorbBarO = frame.healthbar:CreateTexture(nil, "ARTWORK");
    frame.healthbar.absorbBarO:SetTexture("Interface\\RaidFrame\\Shield-Overlay");
    frame.healthbar.absorbBarO:SetAllPoints(frame.healthbar.absorbBar);
    frame.healthbar.absorbBarO:SetAlpha(0.8);
    frame.healthbar.absorbBarO:Show();

    frame.healthbar.shieldBar = frame.healthbar:CreateTexture(nil, "ARTWORK");
    frame.healthbar.shieldBar:SetTexture("Interface\\addons\\asUnitFrame\\UI-StatusBar");
    frame.healthbar.shieldBar:SetVertexColor(0, 0, 0);
    frame.healthbar.shieldBar:SetAlpha(0.5);
    frame.healthbar.shieldBar:Hide();

    frame.healthbar.incominghealBar = frame.healthbar:CreateTexture(nil, "ARTWORK");
    frame.healthbar.incominghealBar:SetTexture("Interface\\addons\\asUnitFrame\\UI-StatusBar");
    frame.healthbar.incominghealBar:SetVertexColor(0, 1, 0);
    frame.healthbar.incominghealBar:SetAlpha(0.6);
    frame.healthbar.incominghealBar:Hide();


    frame.healthbar.bg = frame.healthbar:CreateTexture(nil, "BACKGROUND");
    frame.healthbar.bg:SetPoint("TOPLEFT", frame.healthbar, "TOPLEFT", -1, 1);
    frame.healthbar.bg:SetPoint("BOTTOMRIGHT", frame.healthbar, "BOTTOMRIGHT", 1, -1);

    frame.healthbar.bg:SetTexture("Interface\\Addons\\asUnitFrame\\border.tga");
    frame.healthbar.bg:SetTexCoord(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
    frame.healthbar.bg:SetVertexColor(0, 0, 0, 1);

    frame.healthbar.pvalue = frame.healthbar:CreateFontString(nil, "ARTWORK");
    frame.healthbar.pvalue:SetFont(STANDARD_TEXT_FONT, fontsize + 1, FontOutline);
    frame.healthbar.pvalue:SetTextColor(1, 1, 1, 1)

    frame.healthbar.hvalue = frame.healthbar:CreateFontString(nil, "ARTWORK");
    frame.healthbar.hvalue:SetFont(STANDARD_TEXT_FONT, fontsize - 1, FontOutline);
    frame.healthbar.hvalue:SetTextColor(1, 1, 1, 1)

    frame.healthbar.name = frame.healthbar:CreateFontString(nil, "ARTWORK");
    frame.healthbar.name:SetFont(CONFIG_FONT, fontsize, FontOutline);
    frame.healthbar.name:SetTextColor(1, 1, 1, 1)

    frame.healthbar.aggro = frame.healthbar:CreateFontString(nil, "ARTWORK");
    frame.healthbar.aggro:SetFont(STANDARD_TEXT_FONT, fontsize, FontOutline);
    frame.healthbar.aggro:SetTextColor(1, 1, 1, 1)

    frame.healthbar.classtext = frame.healthbar:CreateFontString(nil, "ARTWORK");
    frame.healthbar.classtext:SetFont(STANDARD_TEXT_FONT, fontsize - 1, FontOutline);
    frame.healthbar.classtext:SetTextColor(1, 1, 1, 1)


    if x < 0 then
        frame.healthbar.pvalue:SetPoint("LEFT", frame.healthbar, "LEFT", 2, 0);
        frame.healthbar.hvalue:SetPoint("RIGHT", frame.healthbar, "RIGHT", -2, 0);
        frame.healthbar.name:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 2, 1);
        frame.healthbar.classtext:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", -2, 1);
        frame.healthbar.aggro:SetPoint("BOTTOMRIGHT", frame.healthbar.classtext, "BOTTOMLEFT", -1, 0);
    else
        frame.healthbar.pvalue:SetPoint("RIGHT", frame.healthbar, "RIGHT", -2, 0);
        frame.healthbar.hvalue:SetPoint("LEFT", frame.healthbar, "LEFT", 2, 0);
        frame.healthbar.name:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", -2, 1);
        frame.healthbar.classtext:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 2, 1);
        frame.healthbar.aggro:SetPoint("BOTTOMLEFT", frame.healthbar.classtext, "BOTTOMRIGHT", 1, 0);
    end

    if is_small then
        frame.healthbar.classtext:Hide();
        frame.healthbar.aggro:Hide();
    end

    frame.is_small = is_small;


    frame.healthbar.mark = frame.healthbar:CreateFontString(nil, "ARTWORK");
    frame.healthbar.mark:SetFont(STANDARD_TEXT_FONT, fontsize + 2, FontOutline);
    frame.healthbar.mark:SetTextColor(1, 1, 1, 1)
    frame.healthbar.mark:SetPoint("CENTER", frame.healthbar, "CENTER", 0, 0);

    frame.powerbar = CreateFrame("StatusBar", nil, frame);
    frame.powerbar:SetStatusBarTexture("Interface\\addons\\asUnitFrame\\UI-StatusBar")
    frame.powerbar:GetStatusBarTexture():SetHorizTile(false)
    frame.powerbar:SetMinMaxValues(0, 100)
    frame.powerbar:SetValue(100)
    frame.powerbar:SetWidth(hwidth / 2);
    frame.powerbar:SetHeight(powerbarheight)
    frame.powerbar:SetPoint("CENTER", frame.healthbar, "BOTTOM", 0, 0);
    frame.powerbar:SetFrameLevel(frame.healthbar:GetFrameLevel() + 3);
    frame.powerbar:Show();

    frame.powerbar.bg = frame.powerbar:CreateTexture(nil, "BACKGROUND");
    frame.powerbar.bg:SetPoint("TOPLEFT", frame.powerbar, "TOPLEFT", -1, 1);
    frame.powerbar.bg:SetPoint("BOTTOMRIGHT", frame.powerbar, "BOTTOMRIGHT", 1, -1);

    frame.powerbar.bg:SetTexture("Interface\\Addons\\asUnitFrame\\border.tga");
    frame.powerbar.bg:SetTexCoord(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
    frame.powerbar.bg:SetVertexColor(0, 0, 0, 0.8);

    frame.powerbar.value = frame.powerbar:CreateFontString(nil, "ARTWORK");
    frame.powerbar.value:SetFont(STANDARD_TEXT_FONT, fontsize - 2, FontOutline);
    frame.powerbar.value:SetTextColor(1, 1, 1, 1)
    frame.powerbar.value:SetPoint("CENTER", frame.powerbar, "CENTER", 0, 0);

    local castbarheight = height - 5;

    frame.castbar = CreateFrame("StatusBar", nil, frame)
    frame.castbar:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", 0, -3);
    frame.castbar:SetStatusBarTexture("Interface\\addons\\asUnitFrame\\UI-StatusBar")
    frame.castbar:GetStatusBarTexture():SetHorizTile(false)
    frame.castbar:SetMinMaxValues(0, 100)
    frame.castbar:SetValue(100)
    frame.castbar:SetHeight(castbarheight)
    frame.castbar:SetWidth(width - ((castbarheight + 1) * 1.2));
    frame.castbar:SetStatusBarColor(1, 0.9, 0.9);
    frame.castbar:SetAlpha(1);

    frame.castbar.bg = frame.castbar:CreateTexture(nil, "BACKGROUND")
    frame.castbar.bg:SetPoint("TOPLEFT", frame.castbar, "TOPLEFT", -1, 1)
    frame.castbar.bg:SetPoint("BOTTOMRIGHT", frame.castbar, "BOTTOMRIGHT", 1, -1)

    frame.castbar.bg:SetTexture("Interface\\Addons\\asUnitFrame\\border.tga")
    frame.castbar.bg:SetTexCoord(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1)
    frame.castbar.bg:SetVertexColor(0, 0, 0, 0.8);
    frame.castbar.bg:Show();

    frame.castbar.name = frame.castbar:CreateFontString(nil, "OVERLAY");
    frame.castbar.name:SetFont(STANDARD_TEXT_FONT, fontsize - 1);
    frame.castbar.name:SetPoint("LEFT", frame.castbar, "LEFT", 3, 0);

    frame.castbar.time = frame.castbar:CreateFontString(nil, "OVERLAY");
    frame.castbar.time:SetFont(STANDARD_TEXT_FONT, fontsize - 1);
    frame.castbar.time:SetPoint("RIGHT", frame.castbar, "RIGHT", -3, 0);

    frame.castbar:EnableMouse(false);
    frame.castbar:Hide();

    frame.castbar.button = CreateFrame("Button", nil, frame.castbar, "AUFFrameTemplate");
    frame.castbar.button:SetPoint("RIGHT", frame.castbar, "LEFT", -2, 0)
    frame.castbar.button:SetWidth((castbarheight + 1) * 1.1);
    frame.castbar.button:SetHeight(castbarheight + 1);
    frame.castbar.button:SetScale(1);
    frame.castbar.button:SetAlpha(1);
    frame.castbar.button:EnableMouse(false);
    frame.castbar.button.icon:SetTexCoord(.08, .92, .08, .92);
    frame.castbar.button.border:SetTexCoord(0.08, 0.08, 0.08, 0.92, 0.92, 0.08, 0.92, 0.92);
    frame.castbar.button.border:SetVertexColor(0, 0, 0);
    frame.castbar.button.border:Show();
    frame.castbar.button:Show();

    frame.castbar.targetname = frame.castbar:CreateFontString(nil, "OVERLAY");
    frame.castbar.targetname:SetFont(CONFIG_FONT, fontsize - 1);
    frame.castbar.targetname:SetPoint("TOPRIGHT", frame.castbar, "BOTTOMRIGHT", 0, -2);
    frame.debuffupdate = false;
    frame.totemupdate = false;

    if debuffupdate and ns.options.ShowDebuff then
        CreateDebuffFrames(frame, true, fontsize, width, 4);
        frame.debuffupdate = true;
    end

    if ns.options.ShowTotemBar and unit == "player" then
        CreatTotemFrames(frame, true, fontsize, width, MAX_TOTEMS);
        frame:RegisterEvent("PLAYER_TOTEM_UPDATE");
        frame.totemupdate = true;
    end

    frame.updatecount = 1;

    if unit == "focus" or string.find(unit, "boss") then
        frame.updateCastBar = true;
        ns.registerCastBarEvents(frame.castbar, unit);
        frame.castbar:SetScript("OnEvent", ns.onCastBarEvent);
        if ns.options.ShowBossBuff and unit ~= "focus" then
            CreateBuffFrames(frame, true, fontsize, buffsize, buffcount);
            frame.buffupdate = true;
        else
            frame.buffupdate = false;
        end
    else
        frame.updateCastBar = false;
        frame.buffupdate = false
    end

    frame.unit = unit;
    -- 유닛 설정 (예시: 'player' 또는 'target' 등)
    frame:SetAttribute("unit", unit);
    ns.unitframes[unit] = frame;
    SecureUnitButton_OnLoad(frame, frame.unit, OpenContextMenu);
    Mixin(frame, PingableType_UnitFrameMixin);
    frame:SetAttribute("ping-receiver", true);

    if unit == "player" then
        frame:Show();
    else
        RegisterStateDriver(frame, "visibility", "[@" .. unit .. ",exists] show; hide");
    end

    if unit == "focus" or string.find(unit, "boss") then
        frame.bchecktarget = true;
    else
        frame.bchecktarget = false;
    end

    frame:SetScript("OnEvent", onUnitEvent);


    frame.callback = function()
        updateUnit(frame);
    end


    C_Timer.NewTicker(Update_Rate, frame.callback);
end

local function Init()
    ns.SetupOptionPanels();

    AUF_PlayerFrame = CreateFrame("Button", nil, UIParent, "AUFUnitButtonTemplate");
    AUF_TargetFrame = CreateFrame("Button", nil, UIParent, "AUFUnitButtonTemplate");
    AUF_FocusFrame = CreateFrame("Button", nil, UIParent, "AUFUnitButtonTemplate");
    AUF_PetFrame = CreateFrame("Button", nil, UIParent, "AUFUnitButtonTemplate");
    AUF_TargetTargetFrame = CreateFrame("Button", nil, UIParent, "AUFUnitButtonTemplate");


    CreateUnitFrame(AUF_PlayerFrame, "player", -xposition, yposition, config_width, healthheight, powerheight, 12, false,
        false);
    CreateUnitFrame(AUF_TargetFrame, "target", xposition, yposition, config_width, healthheight, powerheight, 12, false,
        false);
    CreateUnitFrame(AUF_FocusFrame, "focus", xposition + config_width, yposition, config_width - 50, healthheight - 15,
        powerheight - 2,
        11,
        false, true);
    CreateUnitFrame(AUF_PetFrame, "pet", -xposition - 50, yposition - 40, config_width - 100, healthheight - 20,
        powerheight - 3,
        9,
        true, true);
    CreateUnitFrame(AUF_TargetTargetFrame, "targettarget", xposition + 50, yposition - 40, config_width - 100,
        healthheight - 20,
        powerheight - 3, 9, true, true);

    AUF_BossFrames = {};
    if (MAX_BOSS_FRAMES) then
        for i = 1, MAX_BOSS_FRAMES do
            AUF_BossFrames[i] = CreateFrame("Button", nil, UIParent, "AUFUnitButtonTemplate");
            CreateUnitFrame(AUF_BossFrames[i], "boss" .. i, xposition + 250, 200 - (i - 1) * 70, config_width - 50,
                healthheight - 15, powerheight - 2, 11);
        end
    end


    C_AddOns.LoadAddOn("asMOD");

    if asMOD_setupFrame then
        asMOD_setupFrame(AUF_PlayerFrame, "AUF_PlayerFrame");
        asMOD_setupFrame(AUF_TargetFrame, "AUF_TargetFrame");
        asMOD_setupFrame(AUF_FocusFrame, "AUF_FocusFrame");
        asMOD_setupFrame(AUF_PetFrame, "AUF_PetFrame");
        asMOD_setupFrame(AUF_TargetTargetFrame, "AUF_TargetTargetFrame");

        if (MAX_BOSS_FRAMES) then
            for i = 1, MAX_BOSS_FRAMES do
                asMOD_setupFrame(AUF_BossFrames[i], "AUF_BossFrame" .. i);
            end
        end
    end
end


local AUF = CreateFrame("Frame");

local function checkFrameAuras(unit)
    local frame = ns.unitframes[unit];
    if frame and frame.buffupdate or frame.debuffupdate then
        ns.UpdateAuras(frame);
    end
end

local bfirst = true;
local function AUF_OnEvent(self, event, arg1, arg2, arg3)
    if bfirst then
        Init();
        bfirst = false;
    end

    if event == "PLAYER_ENTERING_WORLD" then
        ns.HideDefaults();
    elseif (event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_REGEN_DISABLED") then
        checkFrameAuras("target");
        checkFrameAuras("targettarget");
    elseif event == "UNIT_TARGET" then
        checkFrameAuras("targettarget")
    elseif event == "PLAYER_TARGET_CHANGED" then
        checkFrameAuras("target");
        checkFrameAuras("targettarget");
    elseif event == "UNIT_PORTRAIT_UPDATE" then
        local frame = ns.unitframes[arg1];
        if frame and frame.portrait then
            SetPortraitTexture(frame.portrait.portrait, frame.unit, false);
        end
    elseif event == "PORTRAITS_UPDATED" then
        for _, frame in pairs(ns.unitframes) do
            if frame.portrait then
                SetPortraitTexture(frame.portrait.portrait, frame.unit, false);
            end
        end
    elseif event == "PLAYER_FOCUS_CHANGED" then
        checkFrameAuras("focus");
    elseif (event == "INSTANCE_ENCOUNTER_ENGAGE_UNIT") then
        for i = 1, MAX_BOSS_FRAMES do
            local unit = "boss" .. i;
            checkFrameAuras(unit);
        end
    end

    return;
end

AUF:SetScript("OnEvent", AUF_OnEvent)
AUF:RegisterEvent("PLAYER_ENTERING_WORLD");
AUF:RegisterEvent("PLAYER_REGEN_ENABLED");
AUF:RegisterEvent("PLAYER_REGEN_DISABLED");
AUF:RegisterEvent("UNIT_PORTRAIT_UPDATE");
AUF:RegisterEvent("PORTRAITS_UPDATED");
AUF:RegisterEvent("PLAYER_FOCUS_CHANGED");
AUF:RegisterEvent("INSTANCE_ENCOUNTER_ENGAGE_UNIT");
AUF:RegisterUnitEvent("UNIT_TARGET", "target");
AUF:RegisterEvent("PLAYER_TARGET_CHANGED");
