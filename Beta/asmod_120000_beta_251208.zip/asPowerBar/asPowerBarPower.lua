local _, ns              = ...;

function ns.update_power()
    local powerType, powerTypeString = UnitPowerType("player");

    if powerTypeString then
        local info = PowerBarColor[powerTypeString];
        ns.bar:SetStatusBarColor(info.r, info.g, info.b);
    end

    local value = UnitPower("player", powerType);
    local valueMax = UnitPowerMax("player", powerType);

    ns.bar:SetMinMaxValues(0, valueMax)
    ns.bar:SetValue(value)
    ns.bar.text:SetText(tostring(value));
end