local _, ns = ...;

--configurations
local APB_Font = STANDARD_TEXT_FONT;
local APB_FontSize = 12;
local APB_FontOutline = "OUTLINE";
local APB_WIDTH = 240; -- 위치
local APB_X = 0;
local APB_Y = -215;
local APB_HEIGHT = 12
local APB_ALPHA_COMBAT = 1 -- 전투중 알파 값
local APB_ALPHA_NORMAL = 0.5

ns.bupdate_rune = false;
ns.bupdate_stagger = false;
ns.bupdate_partial_power = false;
ns.bsmall_power_bar = false;
ns.brogue  = false;
ns.power_level = nil;

ns.frame = CreateFrame("FRAME", nil, UIParent);

local function update_stagger()
    if not ns.bupdate_stagger then
        return;
    end
    local val = UnitStagger("player");
    local valmax = UnitHealthMax("player");

    ns.combocountbar:SetMinMaxValues(0, valmax)
    ns.combocountbar:SetValue(val)
    ns.combotext:SetText(val);
    ns.combocountbar:Show();
    ns.combotext:Show();
end


local function setup_max_combo(max, countonly)
    if issecretvalue(max) then
        return;
    end

    if max == 0 then
        return;
    end

    local width = (APB_WIDTH - (1 * (max - 1))) / max;
    local combobar = ns.combobars;

    for i = 1, 20 do
        combobar[i]:Hide();
    end

    for i = 1, max do
        combobar[i]:SetWidth(width)
        combobar[i]:Show();
        if countonly then
            combobar[i].bg:SetVertexColor(0, 0, 0, 0.7);
            combobar[i]:SetValue(0);
        end
    end

    if countonly then
        local _, Class = UnitClass("player")
        local color = RAID_CLASS_COLORS[Class];
        ns.combocountbar:SetStatusBarColor(color.r, color.g, color.b);
        ns.combocountbar:Show();

        if ns.bupdate_partial_power then
            ns.combocountbar:SetMinMaxValues(0, max * UnitPowerDisplayMod(ns.power_level));
        else
            ns.combocountbar:SetMinMaxValues(0, max);
        end
    end
end

local function compare_rune(runeAIndex, runeBIndex)
    local runeAStart, runeADuration, runeARuneReady = GetRuneCooldown(runeAIndex);
    local runeBStart, runeBDuration, runeBRuneReady = GetRuneCooldown(runeBIndex);

    if (runeARuneReady ~= runeBRuneReady) then
        return runeARuneReady;
    end

    if (runeAStart ~= runeBStart) then
        return runeAStart < runeBStart;
    end

    return runeAIndex < runeBIndex;
end

local function on_update_rune(self)
    if not self.start then
        return;
    end


    local curr_time = GetTime();
    local curr_duration = curr_time - self.start;

    self.update = 0

    if self.reverse then
        if curr_duration < self.duration then
            self:SetMinMaxValues(0, self.duration * 10)
            self:SetValue((self.duration * 10) - (curr_time - self.start) * 10)
        else
            self:SetMinMaxValues(0, self.duration)
            self:SetValue(0)
            self.start = nil;
        end
    else
        if curr_duration < self.duration then
            self:SetMinMaxValues(0, self.duration * 10)
            self:SetValue((curr_time - self.start) * 10)
        else
            self:SetMinMaxValues(0, self.duration)
            self:SetValue(self.duration)
            self.start = nil;
        end
    end
end

local runeIndexes = { 1, 2, 3, 4, 5, 6 };
local function update_rune()
    table.sort(runeIndexes, compare_rune);

    local combobar = ns.combobars;
    local _, Class = UnitClass("player")
    local color = RAID_CLASS_COLORS[Class];

    for i, index in ipairs(runeIndexes) do
        local start, duration, runeReady = GetRuneCooldown(index);

        if runeReady then
            combobar[i].start = nil;

            combobar[i]:SetStatusBarColor(color.r, color.g, color.b);
            combobar[i]:SetMinMaxValues(0, 1)
            combobar[i]:SetValue(1)
            if combobar[i].ctimer then
                combobar[i].ctimer:Cancel();
            end
        else
            combobar[i]:SetStatusBarColor(1, 1, 1)
            combobar[i].start = start;
            combobar[i].duration = duration;

            local cb = function()
                on_update_rune(combobar[i]);
            end
            if combobar[i].ctimer == nil or combobar[i].ctimer:IsCancelled() then
                combobar[i].ctimer = C_Timer.NewTicker(0.1, cb);
            end
        end
    end
end

local function show_combo(combobar, combo, max, partial)
    if partial then
        ns.combotext:SetText(partial);
        combobar:SetValue(partial);
    else
        ns.combotext:SetText(combo);
        combobar:SetValue(combo);
    end

    if ns.brogue then
        --[[
        local chargedPowerPoints = GetUnitChargedPowerPoints("player");
        for i = 1, max do
            local isCharged = chargedPowerPoints and tContains(chargedPowerPoints, i) or false;
            if isCharged then
                ns.combobars[i].bg:SetVertexColor(1, 1, 1, 0.5);
            else
                ns.combobars[i].bg:SetVertexColor(0, 0, 0, 0.7);
            end
        end
        ]]
    end

    setup_max_combo(max, true);
end


local function update_combo()
    if ns.power_level == nil then
        return;
    end

    local combobar = ns.combocountbar;

    local power = UnitPower("player", ns.power_level);
    local max = UnitPowerMax("player", ns.power_level);

    local partial = nil;

    if ns.bupdate_partial_power then
        partial = UnitPower("player", ns.power_level, true);
    end

    show_combo(combobar, power, max, partial);
end

local function update_power()
    local powerType, powerTypeString = UnitPowerType("player");

    if powerTypeString then
        local info = PowerBarColor[powerTypeString];
        ns.bar:SetStatusBarColor(info.r, info.g, info.b);
    end

    local value = UnitPower("player", powerType);
    local valueMax = UnitPowerMax("player", powerType);

    ns.bar:SetMinMaxValues(0, valueMax)
    ns.bar:SetValue(value)
    ns.bar.text:SetText(tostring(value));
end


local function init()
    local localizedClass, englishClass = UnitClass("player")
    local spec = C_SpecializationInfo.GetSpecialization();

    if spec == nil or spec > 4 or (englishClass ~= "DRUID" and spec > 3) then
        spec = 1;
    end

    ns.frame:UnregisterEvent("UNIT_POWER_UPDATE")
    ns.frame:UnregisterEvent("UNIT_DISPLAYPOWER");
    ns.frame:UnregisterEvent("UPDATE_SHAPESHIFT_FORM");
    ns.frame:UnregisterEvent("RUNE_POWER_UPDATE");
    ns.frame:UnregisterEvent("SPELL_ACTIVATION_OVERLAY_SHOW");
    ns.frame:UnregisterEvent("SPELL_ACTIVATION_OVERLAY_HIDE");

    if ns.frame.timerPowerBar then
        ns.frame.timerPowerBar:Cancel()
    end

    if ns.frame.timerPower then
        ns.frame.timerPower:Cancel()
    end

    if ns.frame.timerStagger then
        ns.frame.timerStagger:Cancel()
    end

    ns.bupdate_rune = false;
    ns.power_level = nil;
    ns.brogue = false;

    ns.combotext:SetText("");
    ns.combotext:Hide();
    ns.combocountbar:Hide();

    for i = 1, 20 do
        ns.combobars[i]:Hide();
    end



    if (englishClass == "EVOKER") then
        ns.power_level = Enum.PowerType.Essence;
        ns.bsmall_power_bar = true;

        if (spec and spec == 2) then
            ns.bsmall_power_bar = false;
        end
    end

    if (englishClass == "PALADIN") then
        ns.power_level = Enum.PowerType.HolyPower;
    end

    if (englishClass == "MAGE") then
        if (spec and spec == 1) then
            ns.power_level = Enum.PowerType.ArcaneCharges
            ns.bsmall_power_bar = false;
        end

        if (spec and spec == 2) then
            ns.bsmall_power_bar = true;
        end

        if (spec and spec == 3) then
            ns.bsmall_power_bar = true;
        end
    end

    if (englishClass == "WARLOCK") then
        ns.power_level = Enum.PowerType.SoulShards
        ns.bsmall_power_bar = true;

        if (spec and spec == 3) then
            ns.bupdate_partial_power = true;
        end
    end

    if (englishClass == "DRUID") then
        ns.power_level = Enum.PowerType.ComboPoints        
    end

    if (englishClass == "MONK") then
        if (spec and spec == 1) then
            ns.bupdate_stagger = true;
        end

        if (spec and spec == 3) then
            ns.power_level = Enum.PowerType.Chi
        end
    end

    if (englishClass == "ROGUE") then
        ns.power_level = Enum.PowerType.ComboPoints
        ns.brogue = true;
    end

    if (englishClass == "DEATHKNIGHT") then
        setup_max_combo(6);
        update_rune()
        ns.frame:RegisterEvent("RUNE_POWER_UPDATE");
        ns.bupdate_rune = true;
    end

    if (englishClass == "PRIEST") then
    end

    if (englishClass == "WARRIOR") then
    end

    if (englishClass == "DEMONHUNTER") then

    end

    if (englishClass == "HUNTER") then
    end

    if (englishClass == "SHAMAN") then
        if spec and spec == 2 then
            ns.frame:RegisterEvent("SPELL_ACTIVATION_OVERLAY_SHOW");
            ns.frame:RegisterEvent("SPELL_ACTIVATION_OVERLAY_HIDE");
            ns.bsmall_power_bar = true;
        end
    end

    if ns.power_level then
        ns.combocountbar:Show();
        --ns.combotext:Show();
        ns.frame:RegisterUnitEvent("UNIT_POWER_UPDATE", "player");
        ns.frame:RegisterUnitEvent("UNIT_DISPLAYPOWER", "player");
    end

    ns.bar:SetHeight(APB_HEIGHT * 1.5);
    ns.bar:Show();
    ns.bar.text:Show();

    ns.frame.timerPowerBar = C_Timer.NewTicker(0.1, update_power);
    ns.frame.timerPower = C_Timer.NewTicker(0.2, update_combo);
    ns.frame.timerStagger = C_Timer.NewTicker(0.2, update_stagger);

    if ns.bsmall_power_bar then
        ns.bar:SetHeight(APB_HEIGHT * 0.5);
        ns.bar.text:Hide();
    end
end

local mwc = 0;
local mwc_spells = {
    [170588] = 1,
    [187890] = 5,
    [467442] = 10,
}

local function on_event(self, event, arg1, arg2, arg3, ...)
    if event == "UNIT_POWER_UPDATE" then
        update_combo();
    elseif event == "RUNE_POWER_UPDATE" then
        update_rune();
        --[[
    elseif event == "SPELL_ACTIVATION_OVERLAY_SHOW" then
		local spellID = arg1;
        print(spellID..mwc_spells[spellID]);
        
	elseif event == "SPELL_ACTIVATION_OVERLAY_HIDE" then
        local spellID = arg1;
        if spellID == 344179 then
            mwc = 0;
        end
        print (mwc);
        ]]
        
    elseif event == "PLAYER_ENTERING_WORLD" then
        if UnitAffectingCombat("player") then
            ns.frame:SetAlpha(APB_ALPHA_COMBAT);
        else
            ns.frame:SetAlpha(APB_ALPHA_NORMAL);
        end

        C_Timer.After(0.5, init);
        C_Timer.After(0.5, update_combo);
    elseif (event == "TRAIT_CONFIG_UPDATED") or (event == "TRAIT_CONFIG_LIST_UPDATED") or event ==
        "ACTIVE_TALENT_GROUP_CHANGED" then
        C_Timer.After(0.5, init);
        C_Timer.After(0.5, update_combo); 
    elseif event == "PLAYER_REGEN_DISABLED" then
        ns.frame:SetAlpha(APB_ALPHA_COMBAT);
    elseif event == "PLAYER_REGEN_ENABLED" then
        ns.frame:SetAlpha(APB_ALPHA_NORMAL);
    end

    return;
end

do
    ns.frame:SetPoint("BOTTOM", UIParent, "CENTER", APB_X, APB_Y)
    ns.frame:SetWidth(APB_WIDTH)
    ns.frame:SetHeight(APB_HEIGHT)
    ns.frame:SetFrameLevel(9100);
    ns.frame:Show();

    ns.bar = CreateFrame("StatusBar", nil, ns.frame)
    ns.bar:SetStatusBarTexture("Interface\\Addons\\asPowerBar\\UI-StatusBar")
    ns.bar:GetStatusBarTexture():SetHorizTile(false)
    ns.bar:SetMinMaxValues(0, 100)
    ns.bar:SetValue(100)
    ns.bar:SetWidth(APB_WIDTH)
    ns.bar:SetHeight(APB_HEIGHT)
    ns.bar:SetPoint("BOTTOM", ns.frame, "BOTTOM", 0, 0)
    ns.bar:Hide();
    ns.bar:EnableMouse(false);

    ns.bar.bg = ns.bar:CreateTexture(nil, "BACKGROUND");
    ns.bar.bg:SetPoint("TOPLEFT", ns.bar, "TOPLEFT", -1, 1);
    ns.bar.bg:SetPoint("BOTTOMRIGHT", ns.bar, "BOTTOMRIGHT", 1, -1);

    ns.bar.bg:SetTexture("Interface\\Addons\\asPowerBar\\border.tga");
    ns.bar.bg:SetTexCoord(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
    ns.bar.bg:SetVertexColor(0, 0, 0, 0.8);

    ns.bar.text = ns.bar:CreateFontString(nil, "ARTWORK");
    ns.bar.text:SetFont(APB_Font, APB_FontSize, APB_FontOutline);
    ns.bar.text:SetPoint("CENTER", ns.bar, "CENTER", 0, 0);
    ns.bar.text:SetTextColor(1, 1, 1, 1);

    ns.combocountbar = CreateFrame("StatusBar", nil, ns.frame);
    ns.combocountbar:SetStatusBarTexture("Interface\\Addons\\asPowerBar\\UI-StatusBar");
    ns.combocountbar:GetStatusBarTexture():SetHorizTile(false);
    ns.combocountbar:SetFrameLevel(9000);
    ns.combocountbar:SetMinMaxValues(0, 100);
    ns.combocountbar:SetValue(100);
    ns.combocountbar:SetHeight(APB_HEIGHT);
    ns.combocountbar:SetWidth(20);

    ns.combocountbar.bg = ns.combocountbar:CreateTexture(nil, "BACKGROUND");
    ns.combocountbar.bg:SetPoint("TOPLEFT", ns.combocountbar, "TOPLEFT", -1, 1);
    ns.combocountbar.bg:SetPoint("BOTTOMRIGHT", ns.combocountbar, "BOTTOMRIGHT", 1, -1);

    ns.combocountbar.bg:SetTexture("Interface\\Addons\\asPowerBar\\border.tga");
    ns.combocountbar.bg:SetTexCoord(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
    ns.combocountbar.bg:SetVertexColor(0, 0, 0, 0.8);
    ns.combocountbar:SetPoint("BOTTOMLEFT", ns.bar, "TOPLEFT", 0, 1);
    ns.combocountbar:SetWidth(APB_WIDTH);
    ns.combocountbar:SetStatusBarColor(1, 1, 1);
    ns.combocountbar:Hide();

    ns.combotext = ns.frame:CreateFontString(nil, "OVERLAY");
    ns.combotext:SetFont(APB_Font, APB_FontSize - 2, APB_FontOutline);
    ns.combotext:SetPoint("CENTER", ns.combocountbar, "CENTER", 0, 0);
    ns.combotext:SetTextColor(1, 1, 1, 1)
    ns.combotext:Hide();

    ns.combobars = {};

    for i = 1, 20 do
        ns.combobars[i] = CreateFrame("StatusBar", nil, ns.frame);
        ns.combobars[i]:SetStatusBarTexture("Interface\\Addons\\asPowerBar\\UI-StatusBar");
        ns.combobars[i]:GetStatusBarTexture():SetHorizTile(false);
        ns.combobars[i]:SetFrameLevel(9100);
        ns.combobars[i]:SetMinMaxValues(0, 100);
        ns.combobars[i]:SetValue(100);
        ns.combobars[i]:SetHeight(APB_HEIGHT);
        ns.combobars[i]:SetWidth(20);

        ns.combobars[i].bg = ns.combobars[i]:CreateTexture(nil, "BACKGROUND");
        ns.combobars[i].bg:SetPoint("TOPLEFT", ns.combobars[i], "TOPLEFT", -1, 1);
        ns.combobars[i].bg:SetPoint("BOTTOMRIGHT", ns.combobars[i], "BOTTOMRIGHT", 1, -1);

        ns.combobars[i].bg:SetTexture("Interface\\Addons\\asPowerBar\\border.tga");
        ns.combobars[i].bg:SetTexCoord(0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1);
        ns.combobars[i].bg:SetVertexColor(0, 0, 0, 0.8);

        if i == 1 then
            ns.combobars[i]:SetPoint("BOTTOMLEFT", ns.bar, "TOPLEFT", 0, 1);
        else
            ns.combobars[i]:SetPoint("LEFT", ns.combobars[i - 1], "RIGHT", 1, 0);
        end

        ns.combobars[i]:Hide();
        ns.combobars[i]:EnableMouse(false);
    end

    C_AddOns.LoadAddOn("asMOD");

    if asMOD_setupFrame then
        asMOD_setupFrame(ns.frame, "asPowerBar");
    end

    ns.frame:SetScript("OnEvent", on_event)

    ns.frame:RegisterEvent("PLAYER_ENTERING_WORLD");
    ns.frame:RegisterEvent("PLAYER_REGEN_DISABLED");
    ns.frame:RegisterEvent("PLAYER_REGEN_ENABLED");
    ns.frame:RegisterEvent("TRAIT_CONFIG_UPDATED");
    ns.frame:RegisterEvent("TRAIT_CONFIG_LIST_UPDATED");
    ns.frame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED");

    if UnitAffectingCombat("player") then
        ns.frame:SetAlpha(APB_ALPHA_COMBAT);
    else
        ns.frame:SetAlpha(APB_ALPHA_NORMAL);
    end
end
