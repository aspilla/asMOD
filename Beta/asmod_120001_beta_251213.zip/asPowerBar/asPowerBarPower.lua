local _, ns = ...;

ns.powermax = 100;

local function getcost(powerType)
    local cost = 0;


    local spellID = select(9, UnitCastingInfo("player"));

    if spellID then
        local costTable = C_Spell.GetSpellPowerCost(spellID) or {};
        for _, costInfo in pairs(costTable) do
            if costInfo.type == powerType then
                cost = costInfo.cost;
                break;
            end
        end
    end


    return cost
end

local function updatepowercost(realbar, bar, amount)
    if not amount or (amount == 0) then
        bar:Hide();
        return
    end

    local previousTexture = realbar:GetStatusBarTexture();

    local gen = false;

    bar:ClearAllPoints();

    if amount < 0 then
        amount = 0 - amount;
        gen = true;
        bar:SetPoint("TOPLEFT", previousTexture, "TOPRIGHT", 0, 0);
        bar:SetPoint("BOTTOMLEFT", previousTexture, "BOTTOMRIGHT", 0, 0);
    else
        bar:SetPoint("TOPRIGHT", previousTexture, "TOPRIGHT", 0, 0);
        bar:SetPoint("BOTTOMRIGHT", previousTexture, "BOTTOMRIGHT", 0, 0);
    end

    local totalWidth, totalHeight = realbar:GetSize();
    local barSize = (amount / ns.powermax) * totalWidth;
    bar:SetWidth(barSize);

    if gen then
        bar:SetVertexColor(1, 1, 1)
    else
        bar:SetVertexColor(0.5, 0.5, 0.5)
    end
    bar:Show();
end

function ns.update_power()
    local powerType, powerTypeString = UnitPowerType("player");

    if powerTypeString then
        local info = PowerBarColor[powerTypeString];
        ns.bar:SetStatusBarColor(info.r, info.g, info.b);
    end

    local value = UnitPower("player", powerType);
    local valueMax = UnitPowerMax("player", powerType);

    if not issecretvalue(valueMax) and ns.powermax ~= valueMax then
        ns.powermax = valueMax;
    end

    local cost = getcost(powerType);

    ns.bar:SetMinMaxValues(0, valueMax)
    ns.bar:SetValue(value, Enum.StatusBarInterpolation.ExponentialEaseOut);
    ns.bar.text:SetText(tostring(value));

    updatepowercost(ns.bar, ns.bar.predictbar, cost);
end
