# asGCDBar (Midnight)

Simple status bar to visualize the player's Global Cooldown (GCD)
![asGCDBar](https://github.com/aspilla/asMOD/blob/main/.Pictures/asGCDBar.jpg?raw=true)

## Configuration
If `asMOD` is installed, the position of the bar can be more easily adjusted and saved using `asMOD`'s `/asConfig` command or similar interface.

---

# asGCDBar (한밤)

전역 재사용 대기시간(GCD) 표시 바
![asGCDBar](https://github.com/aspilla/asMOD/blob/main/.Pictures/asGCDBar.jpg?raw=true)

## 설정
`asMOD`가 설치된 경우, `asMOD`의 `/asConfig` 명령 또는 유사한 인터페이스를 사용하여 바의 위치 지정 가능
