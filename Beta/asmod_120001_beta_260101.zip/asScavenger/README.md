# asScavenger (Midnight)

Automatically sells all "Poor" quality (gray) items in your bags whenever you interact with a merchant.

## Key Features

* **Auto-Sell Junk**

## Configuration

* No configuration 

---

# asScavenger (한밤)

상인 창을 열 때 가방에 있는 모든 "일반" 등급(회색) 아이템을 자동으로 상인에게 판매.

## 주요 기능

*   **자동 잡템 판매**

## 설정

옵션 없음.