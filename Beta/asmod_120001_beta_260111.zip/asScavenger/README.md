# asScavenger (Midnight)

Auto-sell Junk Items

## Key Features

* **Automatically sells all `Poor` quality (gray) items in your bags when opening a merchant window.**

## Configuration

No options.

---

# asScavenger (한밤)

자동 잡템 판매

## 주요 기능

*   **상인 거래창을 열 때 가방에 있는 모든 `회색` 등급 아이템을 자동으로 판매.**

## 설정

옵션 없음.