local _, ns = ...;


function ns.checkstorm()
    local combo = 0;

    if C_Secrets.GetSpellAuraSecrecy(344179) == 0 then
        local aurastorm = C_UnitAuras.GetUnitAuraBySpellID("player", 344179);

        if aurastorm then
            combo = aurastorm.applications;
        end
    end

    if combo then
        ns.show_combo(combo, 10);
    end
end
