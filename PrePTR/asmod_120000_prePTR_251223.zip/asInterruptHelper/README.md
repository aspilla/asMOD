# asInterruptHelper (Mid Night)

Tracks and displays the cooldown of your interrupt or stun spells when your Focus, Mouseover, or Current Target starts casting.

### Target / Focus View
![asInterruptHelper(Target/Focus)](https://github.com/aspilla/asMOD/blob/main/.Pictures/asInterruptHelper_target.jpg?raw=true)

### Mouseover View
![asInterruptHelper(Mouseover)](https://github.com/aspilla/asMOD/blob/main/.Pictures/asInterruptHelper.jpg?raw=true)

## Key Features

* **Visual Integration** (Recommended with `asTargetCastBar`):
    * Overlays available interrupt/stun spells directly on the Target and Focus cast bars.
    * Displays the icon near the mouse cursor for Mouseover targets.
* **Interrupt Logic**:
    * Displays your primary interrupt spell when an interruptible spell is being cast.
    * If your interrupt is on cooldown, it suggests a stun spell (only if the target's level allows it).
* **Stun Logic for Non-interruptible Spells**:
    * If a spell is non-interruptible but the target is stunnable (e.g., same level mobs), it displays your stun spells.
* **Smart Priority System**:
    * Spells with shorter cooldowns take priority. (If cooldowns are equal, the spell with the lower ID is prioritized).
    * Priorities are managed via `ns.InterruptSpells` and `ns.StunSpells`.
    * Actual cooldown status is tracked in real-time via the in-game API.

## Configuration

You can modify the following settings via `ESC` > `Options` > `Addons` > `asInterruptHelper`:
* `ShowTarget`: Toggle display for Target's interrupt/stun.
* `ShowFocus`: Toggle display for Focus unit's interrupt/stun.
* `ShowMouseOver`: Toggle display for Mouseover unit's interrupt/stun.
* If you are using **asMOD**, use the `/asConfig` command to adjust the display positions for Target and Focus frames.

---

# asInterruptHelper (한밤)

주시 대상, 마우스오버 대상 또는 현재 대상이 주문 시전시 차단 또는 기절 주문의 쿨을 표시

주시/대상의 경우
![asInterruptHelper(Target/Focus)](https://github.com/aspilla/asMOD/blob/main/.Pictures/asInterruptHelper_target.jpg?raw=true)   

마우스 오버 대상의 경우
![asInterruptHelper(Mouseover)](https://github.com/aspilla/asMOD/blob/main/.Pictures/asInterruptHelper.jpg?raw=true)   

## 주요 기능

*   **asTargetCastBar 와 같이 사용 추천**:
    * 주시대상, 대상 케스팅바 위에 차단 가능 스킬을 표시
    * 마우스 오버 대상이 있는 경우 마우스 커서 위에 표시
*   **차단 가능 스킬 시전 시**:
    * 주 차단 스킬을 표시, 차단 스킬이 없는 경우 쿨일 경우 스턴이 가능한 몹 (Level이 동등한 몹) 인 경우 스턴 스킬을 표시.
*   **차단 불가 스킬 시전 시**:
    * 스턴이 가능한 몹 (Level이 동등한 몹) 인 경우 스턴 스킬을 표시.
*   **스킬 우선 순위**:
    * 쿨이 짧은 스킬이 우선순위를 가짐. (쿨이 같은경우 ID 가 작은수 인 경우) 
    * `ns.InterruptSpells`, `ns.StunSpells` 내에 등록되어 있는 쿨 기준이며, 이 값을 조정하여 우선순위 조정이 가능합니다.
    * 실제 스킬의 쿨은 해당 값이 아닌 API를 통해 확인합니다. 

## 설정

`ESC` > `설정` > `애드온` > `asInterruptHelper` 에서 다음 설정 변경 가능

*   `ShowTarget`: 대상 차단 스킬 표시 여부
*   `ShowFocus` : 주시 대상의 차단 스킬 표시 여부
*   `ShowMouseOver` : 마우스 오버 대상의 차단 스킬 표시 여부

`asMOD` 사용시 `/asConfig` 명령어로 대상/주시와의 거리 표시 위치 변경 가능